<?php
/**
 * Plugin Name: Criu Asistente Comercial
 * Description: Asistente comercial de Telegram para WooCommerce y zonas informativas de Elementor.
 * Version: 0.4.0
 * Requires PHP: 8.0
 * Text Domain: triu-asistente-comercial
 */

defined( 'ABSPATH' ) || exit;

define( 'TRIU_COMMERCIAL_VERSION', '0.4.0' );
define( 'TRIU_COMMERCIAL_DIR', plugin_dir_path( __FILE__ ) );

require_once TRIU_COMMERCIAL_DIR . 'includes/class-config.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-auth.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-hub.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-audit.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-product-service.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-telegram.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-intent.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-media.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-elementor.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-conversation.php';
require_once TRIU_COMMERCIAL_DIR . 'includes/class-admin.php';

/**
 * Return the product action service. The caller must authenticate and bind the
 * actor before invoking it; the service performs a second permission check.
 *
 * @return Triu_Commercial_Product_Service
 */
function triu_commercial_products() {
	static $service = null;
	if ( null === $service ) {
		$service = new Triu_Commercial_Product_Service();
	}
	return $service;
}

add_filter( 'triu_commercial_user_can', array( 'Triu_Commercial_Auth', 'can' ), 10, 4 );
add_action( 'init', array( 'Triu_Commercial_Audit', 'register' ) );
add_action( 'rest_api_init', array( 'Triu_Commercial_Telegram', 'register_route' ) );
add_action( 'rest_api_init', array( 'Triu_Commercial_Hub', 'register_routes' ) );
add_action( 'admin_menu', array( 'Triu_Commercial_Admin', 'register_menu' ) );
add_action( 'admin_init', array( 'Triu_Commercial_Hub', 'maybe_register' ) );
add_action( 'admin_post_triu_commercial_add_slot', array( 'Triu_Commercial_Admin', 'add_slot' ) );
add_action( 'admin_post_triu_commercial_remove_slot', array( 'Triu_Commercial_Admin', 'remove_slot' ) );
add_action( 'admin_post_triu_commercial_hub', array( 'Triu_Commercial_Admin', 'connect_hub' ) );

add_action(
	'admin_notices',
	static function () {
		if ( ! current_user_can( 'activate_plugins' ) || class_exists( 'WooCommerce' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Criu Asistente Comercial necesita WooCommerce para gestionar productos.', 'triu-asistente-comercial' ) . '</p></div>';
	}
);
