<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Admin {
	private static function check( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No tienes permiso para administrar el asistente.' );
		}
		check_admin_referer( $action );
	}

	private static function redirect( $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'triu-commercial', 'triu_notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function register_menu() {
		add_menu_page( 'Criu Asistente Comercial', 'Asistente Criu', 'manage_options', 'triu-commercial', array( __CLASS__, 'page' ), 'dashicons-format-chat', 56 );
	}

	public static function save_settings() {
		self::check( 'triu_commercial_save_settings' );
		$bot_token = trim( (string) ( $_POST['bot_token'] ?? '' ) );
		$openai_key = trim( (string) ( $_POST['openai_key'] ?? '' ) );
		if ( '' !== $bot_token ) {
			if ( ! preg_match( '/^[0-9]+:[A-Za-z0-9_-]+$/', $bot_token ) ) {
				self::redirect( 'invalid_bot_token' );
			}
			Triu_Commercial_Config::set( 'bot_token', $bot_token );
			Triu_Commercial_Config::set( 'bot_username', '' );
		}
		if ( '' !== $openai_key ) {
			Triu_Commercial_Config::set( 'openai_key', $openai_key );
		}
		$model = sanitize_text_field( (string) ( $_POST['openai_model'] ?? 'gpt-4o-mini' ) );
		if ( ! preg_match( '/^[a-zA-Z0-9._-]{3,80}$/', $model ) ) {
			$model = 'gpt-4o-mini';
		}
		Triu_Commercial_Config::set( 'openai_model', $model );
		if ( ! Triu_Commercial_Config::get( 'service_user_id' ) ) {
			Triu_Commercial_Config::set( 'service_user_id', get_current_user_id() );
		}
		self::redirect( 'settings_saved' );
	}

	public static function create_pair_code() {
		self::check( 'triu_commercial_pair_code' );
		$permissions = array_map( 'sanitize_key', (array) ( $_POST['permissions'] ?? array() ) );
		if ( Triu_Commercial_Config::get( 'hub_site_id' ) ) {
			$url = Triu_Commercial_Hub::create_invitation( $permissions );
			if ( is_wp_error( $url ) ) {
				self::redirect( 'pair_error' );
			}
			set_transient( 'triu_pair_admin_' . get_current_user_id(), $url, 1200 );
			self::redirect( 'pair_code_created' );
		}
		$code = Triu_Commercial_Auth::create_pair_code( $permissions );
		set_transient( 'triu_pair_admin_' . get_current_user_id(), $code, 1200 );
		self::redirect( 'pair_code_created' );
	}

	public static function revoke_user() {
		self::check( 'triu_commercial_revoke' );
		$id = sanitize_text_field( (string) ( $_POST['telegram_id'] ?? '' ) );
		Triu_Commercial_Auth::revoke( $id );
		self::redirect( Triu_Commercial_Hub::revoke_remote( $id ) ? 'user_revoked' : 'user_revoked_hub_pending' );
	}

	public static function add_slot() {
		self::check( 'triu_commercial_add_slot' );
		$result = Triu_Commercial_Elementor::add_slot( array(
			'label' => sanitize_text_field( (string) ( $_POST['label'] ?? '' ) ),
			'post_id' => absint( $_POST['post_id'] ?? 0 ),
			'element_id' => sanitize_text_field( (string) ( $_POST['element_id'] ?? '' ) ),
			'kind' => sanitize_key( (string) ( $_POST['kind'] ?? '' ) ),
			'setting_key' => sanitize_key( (string) ( $_POST['setting_key'] ?? '' ) ),
			'item_field' => sanitize_key( (string) ( $_POST['item_field'] ?? '' ) ),
		) );
		self::redirect( is_wp_error( $result ) ? 'slot_error' : 'slot_added' );
	}

	public static function remove_slot() {
		self::check( 'triu_commercial_remove_slot' );
		Triu_Commercial_Elementor::remove_slot( sanitize_text_field( (string) ( $_POST['slot_id'] ?? '' ) ) );
		self::redirect( 'slot_removed' );
	}

	public static function connect_webhook() {
		self::check( 'triu_commercial_webhook' );
		$result = Triu_Commercial_Telegram::set_webhook();
		Triu_Commercial_Config::set( 'webhook_connected_at', is_wp_error( $result ) ? '' : current_time( 'mysql', true ) );
		self::redirect( is_wp_error( $result ) ? 'webhook_error' : 'webhook_connected' );
	}

	public static function connect_hub() {
		self::check( 'triu_commercial_hub' );
		$result = Triu_Commercial_Hub::connect();
		self::redirect( is_wp_error( $result ) ? 'hub_error' : 'hub_connected' );
	}

	private static function form_open( $action ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( $action );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$notice = sanitize_key( (string) ( $_GET['triu_notice'] ?? '' ) );
		$messages = array(
			'settings_saved' => 'Configuración guardada.',
			'invalid_bot_token' => 'El token del bot no tiene el formato esperado.',
			'pair_code_created' => 'Enlace de invitación creado.',
			'pair_error' => 'No se pudo crear la invitación. Comprueba la conexión con Criu.',
			'user_revoked' => 'Acceso revocado.',
			'user_revoked_hub_pending' => 'Acceso revocado en esta web. El panel Criu no respondió; revisa también el acceso allí.',
			'slot_added' => 'Zona editable registrada.',
			'slot_error' => 'No se pudo registrar la zona. Revisa la página, el elemento y el campo.',
			'slot_removed' => 'Zona editable retirada.',
			'webhook_connected' => 'Telegram quedó conectado con este sitio.',
			'webhook_error' => 'No se pudo conectar el webhook. Revisa el token y la URL HTTPS.',
			'hub_connected' => 'Esta web quedó registrada en el panel comercial de Criu.',
			'hub_error' => 'No se pudo registrar esta web. Revisa la URL HTTPS y el acceso público del sitio.',
		);
		echo '<div class="wrap"><h1>Criu Asistente Comercial</h1>';
		if ( isset( $messages[ $notice ] ) ) {
			echo '<div class="notice notice-info"><p>' . esc_html( $messages[ $notice ] ) . '</p></div>';
		}
		echo '<p>El bot modifica únicamente datos comerciales autorizados. Para cambios de diseño, solicita ayuda a Criu Colombia.</p>';
		echo '<h2>Conexiones</h2>';
		$hub_id = (string) Triu_Commercial_Config::get( 'hub_site_id' );
		echo '<h3>Panel comercial de Criu</h3>';
		echo '<p>Estado: <strong>' . ( $hub_id ? 'registrado' : 'pendiente' ) . '</strong>' . ( $hub_id ? ' · ID ' . esc_html( $hub_id ) : '' ) . '</p>';
		echo '<p>Registra esta web en el panel comercial de Criu. La conexión Codex Bridge se conserva por separado. Gestiona las invitaciones y permisos de Telegram desde el panel Criu.</p>';
		self::form_open( 'triu_commercial_hub' );
		submit_button( $hub_id ? 'Revalidar conexión con Criu' : 'Registrar con Criu', 'secondary' );
		echo '</form>';
		echo '<h2>Zonas informativas de Elementor</h2><p>Registra solo campos que hayas identificado y revisado en la página. El asistente nunca edita colores, animaciones o estructura.</p>';
		self::form_open( 'triu_commercial_add_slot' );
		echo '<table class="form-table"><tr><th>Nombre para el chat</th><td><input name="label" type="text" required class="regular-text"></td></tr>';
		echo '<tr><th>ID de página</th><td><input name="post_id" type="number" min="1" required></td></tr>';
		echo '<tr><th>ID de elemento Elementor</th><td><input name="element_id" type="text" required></td></tr>';
		echo '<tr><th>Tipo</th><td><select name="kind"><option value="text">Texto</option><option value="url">Enlace</option><option value="image">Imagen</option><option value="repeater">Agregar ítem compatible</option></select></td></tr>';
		echo '<tr><th>Campo Elementor</th><td><input name="setting_key" type="text" required placeholder="title, link, image, slides..."></td></tr>';
		echo '<tr><th>Campo del nuevo ítem</th><td><input name="item_field" type="text" placeholder="heading o title, solo para repetidor"></td></tr></table>';
		submit_button( 'Registrar zona', 'secondary' );
		echo '</form>';
		echo '<table class="widefat striped"><thead><tr><th>Zona</th><th>Página</th><th>Tipo</th><th>Campo</th><th>Acción</th></tr></thead><tbody>';
		foreach ( Triu_Commercial_Elementor::slots() as $slot_id => $slot ) {
			echo '<tr><td>' . esc_html( $slot['label'] ) . '</td><td>' . esc_html( get_the_title( $slot['post_id'] ) ) . ' (#' . esc_html( $slot['post_id'] ) . ')</td><td>' . esc_html( $slot['kind'] ) . '</td><td>' . esc_html( $slot['setting_key'] ) . '</td><td>';
			self::form_open( 'triu_commercial_remove_slot' );
			echo '<input type="hidden" name="slot_id" value="' . esc_attr( $slot_id ) . '"><button class="button" type="submit">Quitar</button></form></td></tr>';
		}
		echo '</tbody></table></div>';
	}
}
