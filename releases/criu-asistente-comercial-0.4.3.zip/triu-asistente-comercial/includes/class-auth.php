<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Auth {
	private const USERS_OPTION = 'triu_commercial_users';
	private const PAIR_OPTION = 'triu_commercial_pairing';

	public static function users() {
		$users = get_option( self::USERS_OPTION, array() );
		return is_array( $users ) ? $users : array();
	}

	public static function is_linked( $telegram_id ) {
		$users = self::users();
		$key   = (string) $telegram_id;
		return isset( $users[ $key ] ) && ! empty( $users[ $key ]['active'] );
	}

	public static function can( $allowed, $actor_id, $permission, $object_id ) {
		$users = self::users();
		$key   = (string) $actor_id;
		return isset( $users[ $key ] )
			&& ! empty( $users[ $key ]['active'] )
			&& in_array( $permission, $users[ $key ]['permissions'] ?? array(), true );
	}

	public static function permissions() {
		return array(
			'product.read' => 'Consultar productos',
			'product.update.text' => 'Cambiar textos de productos',
			'product.update.price' => 'Cambiar precios',
			'product.update.stock' => 'Cambiar inventario',
			'product.update.media' => 'Cambiar imágenes de productos',
			'product.trash' => 'Enviar productos a la papelera',
			'product.delete_permanently' => 'Eliminar productos definitivamente',
			'page.update.content' => 'Cambiar zonas de Elementor autorizadas',
		);
	}

	public static function create_pair_code( $permissions ) {
		$allowed = array_keys( self::permissions() );
		$permissions = array_values( array_intersect( $allowed, (array) $permissions ) );
		$code = strtoupper( bin2hex( random_bytes( 16 ) ) );
		$pairings = get_option( self::PAIR_OPTION, array() );
		$pairings = is_array( $pairings ) && ! isset( $pairings['hash'] ) ? $pairings : array();
		$pairings = array_filter( $pairings, static function ( $item ) {
			return is_array( $item ) && (int) ( $item['expires'] ?? 0 ) > time();
		} );
		if ( count( $pairings ) >= 20 ) {
			array_shift( $pairings );
		}
		$hash = hash_hmac( 'sha256', $code, wp_salt( 'auth' ) );
		$pairings[ $hash ] = array( 'expires' => time() + 1200, 'permissions' => $permissions );
		update_option( self::PAIR_OPTION, $pairings, false );
		return $code;
	}

	public static function pair( $telegram_id, $first_name, $code ) {
		$pairings = get_option( self::PAIR_OPTION, array() );
		$hash = hash_hmac( 'sha256', strtoupper( trim( (string) $code ) ), wp_salt( 'auth' ) );
		if ( isset( $pairings['hash'] ) ) {
			$pairings = array( $pairings['hash'] => $pairings );
		}
		$pairing = is_array( $pairings ) ? ( $pairings[ $hash ] ?? null ) : null;
		if ( ! is_array( $pairing ) || time() > (int) ( $pairing['expires'] ?? 0 ) ) {
			return false;
		}
		$users = self::users();
		$users[ (string) $telegram_id ] = array(
			'name' => sanitize_text_field( (string) $first_name ),
			'active' => true,
			'permissions' => $pairing['permissions'],
			'linked_at' => current_time( 'mysql', true ),
		);
		update_option( self::USERS_OPTION, $users, false );
		unset( $pairings[ $hash ] );
		update_option( self::PAIR_OPTION, $pairings, false );
		Triu_Commercial_Audit::record( (string) $telegram_id, 'user.paired', 0, 'ok', array() );
		return true;
	}

	public static function link_from_hub( $telegram_id, $first_name, $permissions ) {
		$allowed = array_keys( self::permissions() );
		$granted = array_values( array_intersect( $allowed, array_map( 'sanitize_key', (array) $permissions ) ) );
		$users = self::users();
		$users[ (string) $telegram_id ] = array(
			'name' => sanitize_text_field( (string) $first_name ),
			'active' => true,
			'permissions' => $granted,
			'linked_at' => current_time( 'mysql', true ),
		);
		update_option( self::USERS_OPTION, $users, false );
		Triu_Commercial_Audit::record( (string) $telegram_id, 'user.paired', 0, 'ok', array( 'source' => 'criu_hub' ) );
	}

	public static function revoke( $telegram_id ) {
		$users = self::users();
		$key   = (string) $telegram_id;
		if ( isset( $users[ $key ] ) ) {
			$users[ $key ]['active'] = false;
			update_option( self::USERS_OPTION, $users, false );
			Triu_Commercial_Audit::record( 'wp:' . get_current_user_id(), 'user.revoked', 0, 'ok', array( 'telegram_id' => $key ) );
		}
	}

	public static function revoke_from_hub( $telegram_id ) {
		$users = self::users();
		$key = (string) $telegram_id;
		if ( isset( $users[ $key ] ) ) {
			$users[ $key ]['active'] = false;
			update_option( self::USERS_OPTION, $users, false );
			Triu_Commercial_Audit::record( 'criu_hub', 'user.revoked', 0, 'ok', array( 'telegram_id' => $key ) );
		}
	}
}
