<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Config {
	private const OPTION = 'triu_commercial_settings';

	public static function all() {
		$value = get_option( self::OPTION, array() );
		return is_array( $value ) ? $value : array();
	}

	public static function get( $key, $default = '' ) {
		$settings = self::all();
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	public static function set( $key, $value ) {
		$settings         = self::all();
		$settings[ $key ] = $value;
		update_option( self::OPTION, $settings, false );
	}

	public static function bot_token() {
		return defined( 'TRIU_COMMERCIAL_TELEGRAM_TOKEN' ) ? TRIU_COMMERCIAL_TELEGRAM_TOKEN : self::get( 'bot_token' );
	}

	public static function openai_key() {
		return defined( 'TRIU_COMMERCIAL_OPENAI_KEY' ) ? TRIU_COMMERCIAL_OPENAI_KEY : self::get( 'openai_key' );
	}

	public static function webhook_secret() {
		$secret = self::get( 'webhook_secret' );
		if ( ! $secret ) {
			$secret = wp_generate_password( 48, false, false );
			self::set( 'webhook_secret', $secret );
		}
		return $secret;
	}
}
