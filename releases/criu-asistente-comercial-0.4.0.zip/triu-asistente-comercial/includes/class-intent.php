<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Intent {
	public static function parse( $message ) {
		if ( Triu_Commercial_Config::get( 'hub_site_id' ) ) {
			return Triu_Commercial_Hub::parse_intent( $message );
		}
		$key = Triu_Commercial_Config::openai_key();
		if ( ! is_string( $key ) || '' === $key ) {
			return new WP_Error( 'triu_ai_unconfigured', 'La interpretación en lenguaje natural todavía no está configurada.' );
		}
		$schema = array(
			'type' => 'object',
			'properties' => array(
				'action' => array( 'type' => 'string', 'enum' => array( 'product_search', 'product_update', 'product_image', 'product_delete', 'page_update', 'page_image', 'page_add_item', 'unsupported', 'unknown' ) ),
				'product_query' => array( 'type' => 'string' ),
				'field' => array( 'type' => 'string', 'enum' => array( '', 'name', 'description', 'short_description', 'regular_price', 'sale_price', 'stock_quantity' ) ),
				'value' => array( 'type' => 'string' ),
				'slot_query' => array( 'type' => 'string' ),
				'reply' => array( 'type' => 'string' ),
			),
			'required' => array( 'action', 'product_query', 'field', 'value', 'slot_query', 'reply' ),
			'additionalProperties' => false,
		);
		$payload = array(
			'model' => Triu_Commercial_Config::get( 'openai_model', 'gpt-4o-mini' ),
			'instructions' => 'Clasifica solicitudes de un comercial de WordPress. Responde en JSON según el esquema. Solo identifica intención y datos; no afirmes que hiciste cambios. Para precios usa regular_price o sale_price. Para fotos de producto usa product_image. Para cambios informativos de página o Elementor usa page_update, page_image o page_add_item. Si piden colores, animaciones, estructura, código, plugins, archivos, configuración o tareas fuera del catálogo usa unsupported. Si falta un dato deja su campo como cadena vacía. El reply debe ser una pregunta breve solo para unknown o unsupported.',
			'input' => array( array( 'role' => 'user', 'content' => mb_substr( (string) $message, 0, 2000 ) ) ),
			'text' => array( 'format' => array( 'type' => 'json_schema', 'name' => 'triu_commercial_intent', 'strict' => true, 'schema' => $schema ) ),
			'max_output_tokens' => 300,
		);
		$response = wp_remote_post( 'https://api.openai.com/v1/responses', array(
			'timeout' => 20,
			'headers' => array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' ),
			'body' => wp_json_encode( $payload ),
		) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'triu_ai_unavailable', 'No pude interpretar la solicitud ahora. Intenta de nuevo.' );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || 'completed' !== ( $body['status'] ?? '' ) ) {
			return new WP_Error( 'triu_ai_incomplete', 'No pude interpretar la solicitud. Intenta decirlo de otra forma.' );
		}
		foreach ( $body['output'] ?? array() as $output ) {
			if ( 'message' !== ( $output['type'] ?? '' ) ) {
				continue;
			}
			foreach ( $output['content'] ?? array() as $part ) {
				if ( 'output_text' === ( $part['type'] ?? '' ) && isset( $part['text'] ) ) {
					$intent = json_decode( $part['text'], true );
					if ( is_array( $intent ) && isset( $intent['action'] ) ) {
						return $intent;
					}
				}
			}
		}
		return new WP_Error( 'triu_ai_no_intent', 'No entendí la solicitud. Intenta expresarla de otra forma.' );
	}
}
