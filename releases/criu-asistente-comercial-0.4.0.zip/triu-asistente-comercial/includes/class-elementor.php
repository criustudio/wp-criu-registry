<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Elementor {
	private const SLOTS_OPTION = 'triu_commercial_slots';
	private const PROPOSAL_PREFIX = 'triu_slot_';
	private const TTL = 900;

	public static function slots() {
		$slots = get_option( self::SLOTS_OPTION, array() );
		return is_array( $slots ) ? $slots : array();
	}

	public static function inventory( $post_id ) {
		$document = self::document( $post_id );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$inventory = array();
		self::collect_inventory( $document->get_elements_data(), $inventory );
		return array( 'page_id' => $post_id, 'page_title' => get_the_title( $post_id ), 'elements' => array_slice( $inventory, 0, 200 ) );
	}

	private static function collect_inventory( $elements, &$inventory ) {
		$whitelist = array( 'title', 'heading', 'text', 'editor', 'description', 'button_text', 'caption', 'link', 'button_link', 'url', 'image', 'background_image', 'slides', 'items', 'tabs' );
		foreach ( (array) $elements as $element ) {
			$settings = $element['settings'] ?? array();
			$fields = array();
			foreach ( $whitelist as $key ) {
				if ( array_key_exists( $key, $settings ) ) {
					$value = $settings[ $key ];
					$fields[ $key ] = is_string( $value ) ? mb_substr( wp_strip_all_tags( $value ), 0, 100 ) : ( is_array( $value ) ? 'array (' . count( $value ) . ')' : gettype( $value ) );
				}
			}
			if ( $fields ) {
				$inventory[] = array( 'element_id' => $element['id'] ?? '', 'widget_type' => $element['widgetType'] ?? $element['elType'] ?? '', 'fields' => $fields );
			}
			if ( ! empty( $element['elements'] ) ) {
				self::collect_inventory( $element['elements'], $inventory );
			}
		}
	}

	public static function add_slot( $input ) {
		$kind = $input['kind'] ?? '';
		$key = $input['setting_key'] ?? '';
		$allowed = array(
			'text' => array( 'title', 'heading', 'text', 'editor', 'description', 'button_text', 'caption' ),
			'url' => array( 'link', 'button_link', 'url' ),
			'image' => array( 'image', 'background_image' ),
			'repeater' => array( 'slides', 'items', 'tabs' ),
		);
		if ( empty( $input['label'] ) || empty( $input['post_id'] ) || empty( $input['element_id'] ) || ! isset( $allowed[ $kind ] ) || ! in_array( $key, $allowed[ $kind ], true ) ) {
			return new WP_Error( 'triu_invalid_slot', 'La zona no corresponde a un campo informativo permitido.' );
		}
		if ( 'repeater' === $kind && ! in_array( $input['item_field'] ?? '', array( 'heading', 'title', 'text', 'description' ), true ) ) {
			return new WP_Error( 'triu_invalid_item_field', 'El ítem debe indicar un campo de texto compatible.' );
		}
		$document = self::document( (int) $input['post_id'] );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$elements = $document->get_elements_data();
		$element = self::find_element( $elements, $input['element_id'] );
		if ( ! $element || ! array_key_exists( $key, $element['settings'] ?? array() ) ) {
			return new WP_Error( 'triu_slot_missing', 'Ese campo no existe en el elemento indicado.' );
		}
		$current = $element['settings'][ $key ];
		if ( 'text' === $kind && ! is_string( $current ) ) {
			return new WP_Error( 'triu_slot_type', 'Este campo no contiene texto editable.' );
		}
		if ( 'url' === $kind && ! ( is_string( $current ) || ( is_array( $current ) && array_key_exists( 'url', $current ) ) ) ) {
			return new WP_Error( 'triu_slot_type', 'Este campo no contiene un enlace compatible.' );
		}
		if ( 'image' === $kind && ! ( is_array( $current ) && array_key_exists( 'url', $current ) ) ) {
			return new WP_Error( 'triu_slot_type', 'Este campo no contiene una imagen compatible.' );
		}
		if ( 'repeater' === $kind && ( ! is_array( $element['settings'][ $key ] ) || ! self::supports_repeater( $element['settings'][ $key ], $input['item_field'] ) ) ) {
			return new WP_Error( 'triu_repeater_unsupported', 'Este listado no admite agregar ítems desde el asistente.' );
		}
		$id = wp_generate_uuid4();
		$slots = self::slots();
		$slots[ $id ] = array(
			'label' => sanitize_text_field( $input['label'] ),
			'post_id' => (int) $input['post_id'],
			'element_id' => sanitize_text_field( $input['element_id'] ),
			'kind' => $kind,
			'setting_key' => $key,
			'item_field' => sanitize_key( $input['item_field'] ?? '' ),
		);
		update_option( self::SLOTS_OPTION, $slots, false );
		return $id;
	}

	public static function remove_slot( $id ) {
		$slots = self::slots();
		unset( $slots[ $id ] );
		update_option( self::SLOTS_OPTION, $slots, false );
	}

	public static function matching_slots( $actor_id, $query ) {
		if ( ! Triu_Commercial_Auth::can( false, $actor_id, 'page.update.content', 0 ) ) {
			return new WP_Error( 'triu_forbidden', 'No tienes permiso para cambiar páginas.' );
		}
		$query = self::normalized_words( $query );
		$matched = array();
		$scores = array();
		foreach ( self::slots() as $id => $slot ) {
			$haystack = self::normalized_words( $slot['label'] . ' ' . get_the_title( $slot['post_id'] ) );
			$score = 0;
			if ( '' === $query ) {
				$score = 1;
			} elseif ( false !== strpos( $haystack, $query ) ) {
				$score = 100;
			} else {
				foreach ( array_unique( explode( ' ', $query ) ) as $word ) {
					if ( strlen( $word ) >= 4 && false !== strpos( ' ' . $haystack . ' ', ' ' . $word . ' ' ) ) {
						$score++;
					}
				}
			}
			if ( $score > 0 ) {
				$matched[ $id ] = $slot;
				$scores[ $id ] = $score;
			}
		}
		arsort( $scores );
		$ordered = array();
		foreach ( array_keys( $scores ) as $id ) {
			$ordered[ $id ] = $matched[ $id ];
		}
		return $ordered;
	}

	private static function normalized_words( $text ) {
		$text = remove_accents( mb_strtolower( trim( (string) $text ) ) );
		return trim( preg_replace( '/[^a-z0-9]+/', ' ', $text ) );
	}

	public static function propose( $actor_id, $slot_id, $value, $telegram_file_id = '' ) {
		if ( ! Triu_Commercial_Auth::can( false, $actor_id, 'page.update.content', 0 ) ) {
			return new WP_Error( 'triu_forbidden', 'No tienes permiso para cambiar páginas.' );
		}
		$slots = self::slots();
		if ( ! isset( $slots[ $slot_id ] ) ) {
			return new WP_Error( 'triu_slot_missing', 'La zona ya no está habilitada.' );
		}
		$slot = $slots[ $slot_id ];
		$document = self::document( $slot['post_id'] );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$elements = $document->get_elements_data();
		$element = self::find_element( $elements, $slot['element_id'] );
		if ( ! $element || ! array_key_exists( $slot['setting_key'], $element['settings'] ?? array() ) ) {
			return new WP_Error( 'triu_slot_changed', 'La zona cambió en Elementor y necesita revisión.' );
		}
		if ( 'image' === $slot['kind'] && '' === $telegram_file_id ) {
			return new WP_Error( 'triu_photo_required', 'Envíame la fotografía para esta zona.' );
		}
		if ( 'image' !== $slot['kind'] && '' === trim( (string) $value ) ) {
			return new WP_Error( 'triu_value_required', 'Indica el nuevo contenido para esta zona.' );
		}
		if ( 'url' === $slot['kind'] && ! self::valid_url( $value ) ) {
			return new WP_Error( 'triu_invalid_url', 'El enlace debe ser HTTPS o una ruta interna del sitio.' );
		}
		$proposal_id = wp_generate_uuid4();
		$previous = $element['settings'][ $slot['setting_key'] ];
		set_transient( self::PROPOSAL_PREFIX . $proposal_id, array(
			'actor_id' => (string) $actor_id,
			'slot_id' => $slot_id,
			'value' => 'text' === $slot['kind'] || 'repeater' === $slot['kind'] ? wp_kses_post( (string) $value ) : esc_url_raw( (string) $value ),
			'file_id' => $telegram_file_id,
			'fingerprint' => self::fingerprint( $elements ),
			'previous' => $previous,
		), self::TTL );
		return array( 'proposal_id' => $proposal_id, 'slot' => $slot, 'previous' => $previous, 'value' => $value );
	}

	public static function confirm( $actor_id, $proposal_id, $answer ) {
		if ( 'CONFIRMO' !== trim( (string) $answer ) || ! is_string( $proposal_id ) || ! preg_match( '/^[a-f0-9-]{36}$/i', $proposal_id ) ) {
			return new WP_Error( 'triu_confirmation_required', 'Escribe CONFIRMO para aplicar el cambio.' );
		}
		$state = get_transient( self::PROPOSAL_PREFIX . $proposal_id );
		if ( ! is_array( $state ) || ! hash_equals( $state['actor_id'], (string) $actor_id ) || ! Triu_Commercial_Auth::can( false, $actor_id, 'page.update.content', 0 ) ) {
			return new WP_Error( 'triu_proposal_expired', 'La propuesta venció o no pertenece a esta persona.' );
		}
		$slots = self::slots();
		if ( ! isset( $slots[ $state['slot_id'] ] ) ) {
			return new WP_Error( 'triu_slot_missing', 'La zona ya no está habilitada.' );
		}
		$slot = $slots[ $state['slot_id'] ];
		$document = self::document( $slot['post_id'] );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$elements = $document->get_elements_data();
		if ( ! hash_equals( $state['fingerprint'], self::fingerprint( $elements ) ) ) {
			delete_transient( self::PROPOSAL_PREFIX . $proposal_id );
			return new WP_Error( 'triu_slot_changed', 'La página cambió mientras confirmabas. Revisa el contenido actual.' );
		}
		$attachment_id = 0;
		if ( 'image' === $slot['kind'] ) {
			$attachment_id = Triu_Commercial_Media::from_telegram( $state['file_id'], $slot['post_id'] );
			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}
		}
		$changed = self::update_element( $elements, $slot, $state['value'], $attachment_id );
		if ( ! $changed ) {
			if ( $attachment_id ) {
				wp_delete_attachment( $attachment_id, true );
			}
			return new WP_Error( 'triu_slot_changed', 'No pude ubicar el campo permitido en la página.' );
		}
		$previous_user = get_current_user_id();
		$service_user = (int) Triu_Commercial_Config::get( 'service_user_id', 0 );
		if ( ! $service_user || ! user_can( $service_user, 'edit_post', $slot['post_id'] ) ) {
			if ( $attachment_id ) {
				wp_delete_attachment( $attachment_id, true );
			}
			return new WP_Error( 'triu_editor_unconfigured', 'Falta configurar un usuario editor para guardar esta página.' );
		}
		wp_set_current_user( $service_user );
		try {
			$saved = $document->save( array( 'elements' => $elements ) );
		} catch ( Throwable $error ) {
			$saved = false;
		} finally {
			wp_set_current_user( $previous_user );
		}
		if ( ! $saved ) {
			if ( $attachment_id ) {
				wp_delete_attachment( $attachment_id, true );
			}
			return new WP_Error( 'triu_elementor_save_failed', 'No pude guardar el cambio en Elementor.' );
		}
		delete_transient( self::PROPOSAL_PREFIX . $proposal_id );
		Triu_Commercial_Audit::record( $actor_id, 'page.update.' . $slot['kind'], $slot['post_id'], 'ok', array( 'slot' => $slot['label'], 'previous' => $state['previous'], 'value' => $state['value'], 'attachment_id' => $attachment_id ) );
		return array( 'page_id' => $slot['post_id'], 'page_url' => get_permalink( $slot['post_id'] ), 'slot' => $slot['label'] );
	}

	private static function document( $post_id ) {
		if ( ! class_exists( '\\Elementor\\Plugin' ) ) {
			return new WP_Error( 'triu_elementor_missing', 'Elementor no está disponible.' );
		}
		$document = \Elementor\Plugin::$instance->documents->get( (int) $post_id );
		if ( ! $document || ! $document->is_built_with_elementor() ) {
			return new WP_Error( 'triu_elementor_document_missing', 'Esta página no está construida con Elementor.' );
		}
		return $document;
	}

	private static function fingerprint( $elements ) {
		return hash( 'sha256', wp_json_encode( $elements ) );
	}

	private static function find_element( $elements, $element_id ) {
		foreach ( (array) $elements as $element ) {
			if ( ( $element['id'] ?? '' ) === $element_id ) {
				return $element;
			}
			$found = self::find_element( $element['elements'] ?? array(), $element_id );
			if ( $found ) {
				return $found;
			}
		}
		return null;
	}

	private static function update_element( &$elements, $slot, $value, $attachment_id ) {
		foreach ( $elements as &$element ) {
			if ( ( $element['id'] ?? '' ) === $slot['element_id'] ) {
				$key = $slot['setting_key'];
				if ( ! array_key_exists( $key, $element['settings'] ?? array() ) ) {
					return false;
				}
				switch ( $slot['kind'] ) {
					case 'text':
						$element['settings'][ $key ] = $value;
						return true;
					case 'url':
						$existing = $element['settings'][ $key ];
						if ( is_array( $existing ) ) {
							$existing['url'] = $value;
							$element['settings'][ $key ] = $existing;
						} else {
							$element['settings'][ $key ] = $value;
						}
						return true;
					case 'image':
						$existing = $element['settings'][ $key ];
						if ( ! is_array( $existing ) ) {
							return false;
						}
						$existing['id'] = $attachment_id;
						$existing['url'] = wp_get_attachment_url( $attachment_id );
						$element['settings'][ $key ] = $existing;
						return true;
					case 'repeater':
						$items = $element['settings'][ $key ];
						if ( ! self::supports_repeater( $items, $slot['item_field'] ) ) {
							return false;
						}
						$items[] = array( '_id' => substr( wp_generate_password( 12, false, false ), 0, 8 ), $slot['item_field'] => $value );
						$element['settings'][ $key ] = $items;
						return true;
				}
			}
			if ( isset( $element['elements'] ) && is_array( $element['elements'] ) && self::update_element( $element['elements'], $slot, $value, $attachment_id ) ) {
				return true;
			}
		}
		return false;
	}

	private static function supports_repeater( $items, $field ) {
		if ( ! is_array( $items ) || empty( $items ) ) {
			return false;
		}
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || ! array_key_exists( $field, $item ) ) {
				return false;
			}
		}
		return true;
	}

	private static function valid_url( $value ) {
		$value = trim( (string) $value );
		return ( 0 === strpos( $value, '/' ) && 0 !== strpos( $value, '//' ) ) || 0 === strpos( $value, 'https://' );
	}
}
