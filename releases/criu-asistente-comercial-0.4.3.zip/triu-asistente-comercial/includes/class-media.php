<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Media {
	public static function from_telegram( $file_id, $post_id ) {
		$extension = '';
		if ( Triu_Commercial_Config::get( 'hub_site_id' ) ) {
			$url = Triu_Commercial_Hub::media_url( (string) $file_id );
			if ( ! $url ) {
				return new WP_Error( 'criu_photo_unavailable', 'No pude descargar la fotografía. Intenta enviarla de nuevo.' );
			}
		} else {
			$file = Triu_Commercial_Telegram::api( 'getFile', array( 'file_id' => $file_id ) );
			if ( is_wp_error( $file ) || empty( $file['file_path'] ) ) {
				return new WP_Error( 'triu_photo_unavailable', 'No pude descargar la fotografía. Intenta enviarla de nuevo.' );
			}
			if ( ! empty( $file['file_size'] ) && (int) $file['file_size'] > 10 * MB_IN_BYTES ) {
				return new WP_Error( 'triu_photo_too_large', 'La fotografía supera el límite de 10 MB.' );
			}
			$path = (string) $file['file_path'];
			$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
			if ( ! in_array( $extension, array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) {
				return new WP_Error( 'triu_photo_type', 'Envía una imagen JPG, PNG o WebP.' );
			}
			$url = 'https://api.telegram.org/file/bot' . Triu_Commercial_Config::bot_token() . '/' . ltrim( $path, '/' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$temp = download_url( $url, 20 );
		if ( is_wp_error( $temp ) ) {
			return new WP_Error( 'triu_photo_download', 'No pude descargar la fotografía.' );
		}
		$size = filesize( $temp );
		$image = getimagesize( $temp );
		if ( false === $image || ! in_array( $image['mime'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) || $size > 10 * MB_IN_BYTES ) {
			wp_delete_file( $temp );
			return new WP_Error( 'triu_photo_type', 'La fotografía no tiene un formato admitido.' );
		}
		if ( '' === $extension ) {
			$extension = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp' )[ $image['mime'] ];
		}
		$upload = array(
			'name' => 'triu-telegram-' . wp_generate_password( 8, false, false ) . '.' . $extension,
			'tmp_name' => $temp,
			'type' => $image['mime'],
			'size' => $size,
			'error' => 0,
		);
		$attachment_id = media_handle_sideload( $upload, (int) $post_id );
		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $temp );
			return new WP_Error( 'triu_photo_upload', 'No pude guardar la fotografía en la biblioteca del sitio.' );
		}
		return $attachment_id;
	}
}
