<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Audit {
	public static function register() {
		register_post_type(
			'triu_audit',
			array(
				'label' => 'Registro Triu',
				'public' => false,
				'show_ui' => true,
				'show_in_menu' => false,
				'supports' => array( 'title' ),
				'capabilities' => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap' => true,
			)
		);
	}

	public static function record( $actor, $action, $object_id, $result, $details ) {
		$post_id = wp_insert_post(
			array(
				'post_type' => 'triu_audit',
				'post_status' => 'private',
				'post_title' => sanitize_text_field( $action . ' - ' . $result . ' - ' . $object_id ),
				'post_content' => '',
			),
			true
		);
		if ( is_wp_error( $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, '_triu_actor', sanitize_text_field( (string) $actor ) );
		update_post_meta( $post_id, '_triu_action', sanitize_key( $action ) );
		update_post_meta( $post_id, '_triu_object_id', (int) $object_id );
		update_post_meta( $post_id, '_triu_result', sanitize_key( $result ) );
		update_post_meta( $post_id, '_triu_details', $details );
	}
}
