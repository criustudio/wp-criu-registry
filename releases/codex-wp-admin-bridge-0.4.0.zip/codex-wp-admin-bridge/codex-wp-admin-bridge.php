<?php
/**
 * Plugin Name: Codex WP Admin Bridge
 * Plugin URI: https://openai.com/
 * Description: Administrative bridge for Codex to manage WordPress, WooCommerce, Elementor, JetEngine, and JetBooking through a dedicated token.
 * Version: 0.4.0
 * Author: OpenAI Codex Local
 * License: GPLv2 or later
 * Text Domain: codex-wp-admin-bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Codex_WP_Admin_Bridge' ) ) {
	final class Codex_WP_Admin_Bridge {
		const OPTION_TOKEN           = 'codex_wp_admin_bridge_token';
		const OPTION_SERVICE_USER_ID = 'codex_wp_admin_bridge_service_user_id';
		const OPTION_SITE_LABEL      = 'codex_wp_admin_bridge_site_label';
		const OPTION_SITE_ID         = 'codex_wp_admin_bridge_site_id';
		const OPTION_ENVIRONMENT     = 'codex_wp_admin_bridge_environment';
		const OPTION_REGISTRY_URL    = 'codex_wp_admin_bridge_registry_url';
		const OPTION_REGISTRY_TOKEN  = 'codex_wp_admin_bridge_registry_token';
		const OPTION_REGISTRY_STATUS = 'codex_wp_admin_bridge_registry_status';
		const OPTION_REGISTRY_ERROR  = 'codex_wp_admin_bridge_registry_error';
		const NONCE_ACTION           = 'codex_wp_admin_bridge_settings';
		const REST_NAMESPACE         = 'codex-bridge/v1';
		const INTERNAL_REGISTRY_URL  = 'https://mcp.criu.com.co/register-site/bridge';

		public static function init() {
			register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );

			add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
			add_action( 'admin_menu', array( __CLASS__, 'register_admin_page' ) );
			add_action( 'admin_post_codex_wp_bridge_save_settings', array( __CLASS__, 'handle_settings_save' ) );
			add_action( 'admin_post_codex_wp_bridge_register_site', array( __CLASS__, 'handle_register_site' ) );
		}

		public static function activate() {
			if ( ! get_option( self::OPTION_TOKEN ) ) {
				update_option( self::OPTION_TOKEN, self::generate_token(), false );
			}

			if ( ! get_option( self::OPTION_SERVICE_USER_ID ) ) {
				$admin_user_id = self::get_default_admin_user_id();
				if ( $admin_user_id ) {
					update_option( self::OPTION_SERVICE_USER_ID, $admin_user_id, false );
				}
			}

			if ( ! get_option( self::OPTION_SITE_LABEL ) ) {
				update_option( self::OPTION_SITE_LABEL, get_bloginfo( 'name' ), false );
			}

			if ( ! get_option( self::OPTION_SITE_ID ) ) {
				update_option( self::OPTION_SITE_ID, self::build_default_site_id(), false );
			}

			if ( ! get_option( self::OPTION_ENVIRONMENT ) ) {
				update_option( self::OPTION_ENVIRONMENT, 'production', false );
			}

			if ( ! get_option( self::OPTION_REGISTRY_URL ) ) {
				update_option( self::OPTION_REGISTRY_URL, self::INTERNAL_REGISTRY_URL, false );
			}

			self::maybe_register_site();
		}

		public static function register_admin_page() {
			add_management_page(
				__( 'Codex Bridge', 'codex-wp-admin-bridge' ),
				__( 'Codex Bridge', 'codex-wp-admin-bridge' ),
				'manage_options',
				'codex-wp-admin-bridge',
				array( __CLASS__, 'render_admin_page' )
			);
		}

		public static function render_admin_page() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to access this page.', 'codex-wp-admin-bridge' ) );
			}

			$service_user_id = (int) get_option( self::OPTION_SERVICE_USER_ID );
			$service_user    = $service_user_id ? get_user_by( 'id', $service_user_id ) : false;
			$token           = self::get_token();
			$site_label      = (string) get_option( self::OPTION_SITE_LABEL, get_bloginfo( 'name' ) );
			$site_id         = self::get_site_id();
			$environment     = self::get_environment();
			$endpoint        = rest_url( self::REST_NAMESPACE );
			$registry_url    = self::get_registry_url();
			$registry_status = (string) get_option( self::OPTION_REGISTRY_STATUS, 'not_configured' );
			$registry_error  = (string) get_option( self::OPTION_REGISTRY_ERROR, '' );
			$wp_config_snippet = "define( 'CODEX_WP_ADMIN_BRIDGE_TOKEN', 'REEMPLAZAR_CON_TU_TOKEN_MSP_PRIVADO' );\n" .
				"define( 'CODEX_WP_ADMIN_BRIDGE_SITE_ID', '" . $site_id . "' );\n" .
				"define( 'CODEX_WP_ADMIN_BRIDGE_ENVIRONMENT', '" . $environment . "' );\n" .
				"define( 'CODEX_WP_BRIDGE_REGISTRY_URL', '" . self::INTERNAL_REGISTRY_URL . "' );";
			$admin_users     = get_users(
				array(
					'role__in' => array( 'administrator' ),
					'orderby'  => 'display_name',
					'order'    => 'ASC',
					'fields'   => array( 'ID', 'display_name', 'user_login' ),
				)
			);
			?>
			<div class="wrap">
				<h1><?php echo esc_html__( 'Codex WP Admin Bridge', 'codex-wp-admin-bridge' ); ?></h1>
				<p><?php echo esc_html__( 'Install this plugin temporarily or permanently on a WordPress site, then connect Codex with the bridge token instead of application passwords.', 'codex-wp-admin-bridge' ); ?></p>

				<table class="widefat striped" style="max-width: 980px; margin: 20px 0;">
					<tbody>
						<tr>
							<th style="width: 220px;"><?php echo esc_html__( 'REST base URL', 'codex-wp-admin-bridge' ); ?></th>
							<td><code><?php echo esc_html( $endpoint ); ?></code></td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'Site ID', 'codex-wp-admin-bridge' ); ?></th>
							<td><code><?php echo esc_html( $site_id ); ?></code></td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'Environment', 'codex-wp-admin-bridge' ); ?></th>
							<td><code><?php echo esc_html( $environment ); ?></code></td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'Bridge token', 'codex-wp-admin-bridge' ); ?></th>
							<td><code style="word-break: break-all;"><?php echo esc_html( $token ); ?></code></td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'Service user', 'codex-wp-admin-bridge' ); ?></th>
							<td>
								<?php
								if ( $service_user ) {
									echo esc_html( $service_user->display_name . ' (' . $service_user->user_login . ')' );
								} else {
									echo esc_html__( 'Not configured', 'codex-wp-admin-bridge' );
								}
								?>
							</td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'MCP Hub', 'codex-wp-admin-bridge' ); ?></th>
							<td>
								<code><?php echo esc_html( self::get_registry_url() ); ?></code>
								<p class="description"><?php echo esc_html__( 'This plugin now syncs against the personal MCP Hub directly with the bridge token of this site.', 'codex-wp-admin-bridge' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php echo esc_html__( 'Registry status', 'codex-wp-admin-bridge' ); ?></th>
							<td>
								<code><?php echo esc_html( $registry_status ); ?></code>
								<?php if ( $registry_error ) : ?>
									<p class="description" style="color: #b32d2e;"><?php echo esc_html( $registry_error ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					</tbody>
				</table>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width: 980px;">
					<?php wp_nonce_field( self::NONCE_ACTION ); ?>
					<input type="hidden" name="action" value="codex_wp_bridge_save_settings">

					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="codex-wp-bridge-site-label"><?php echo esc_html__( 'Site label', 'codex-wp-admin-bridge' ); ?></label>
								</th>
								<td>
									<input type="text" class="regular-text" id="codex-wp-bridge-site-label" name="site_label" value="<?php echo esc_attr( $site_label ); ?>">
									<p class="description"><?php echo esc_html__( 'Human-friendly name returned to Codex in site info responses.', 'codex-wp-admin-bridge' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="codex-wp-bridge-site-id"><?php echo esc_html__( 'Site ID', 'codex-wp-admin-bridge' ); ?></label>
								</th>
								<td>
									<input type="text" class="regular-text" id="codex-wp-bridge-site-id" name="site_id" value="<?php echo esc_attr( $site_id ); ?>">
									<p class="description"><?php echo esc_html__( 'Stable short identifier used by your Codex MSP registry.', 'codex-wp-admin-bridge' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="codex-wp-bridge-environment"><?php echo esc_html__( 'Environment', 'codex-wp-admin-bridge' ); ?></label>
								</th>
								<td>
									<select id="codex-wp-bridge-environment" name="environment">
										<?php foreach ( array( 'production', 'staging', 'development' ) as $value ) : ?>
											<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $environment, $value ); ?>>
												<?php echo esc_html( ucfirst( $value ) ); ?>
											</option>
										<?php endforeach; ?>
									</select>
									<p class="description"><?php echo esc_html__( 'Helps Codex distinguish production from test sites.', 'codex-wp-admin-bridge' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row">
									<label for="codex-wp-bridge-service-user"><?php echo esc_html__( 'Service user', 'codex-wp-admin-bridge' ); ?></label>
								</th>
								<td>
									<select id="codex-wp-bridge-service-user" name="service_user_id">
										<?php foreach ( $admin_users as $admin_user ) : ?>
											<option value="<?php echo esc_attr( $admin_user->ID ); ?>" <?php selected( $service_user_id, $admin_user->ID ); ?>>
												<?php echo esc_html( $admin_user->display_name . ' (' . $admin_user->user_login . ')' ); ?>
											</option>
										<?php endforeach; ?>
									</select>
									<p class="description"><?php echo esc_html__( 'All bridge requests run with this administrator identity.', 'codex-wp-admin-bridge' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><?php echo esc_html__( 'Rotate token', 'codex-wp-admin-bridge' ); ?></th>
								<td>
									<label>
										<input type="checkbox" name="rotate_token" value="1">
										<?php echo esc_html__( 'Generate a fresh token on save', 'codex-wp-admin-bridge' ); ?>
									</label>
									<p class="description"><?php echo esc_html__( 'Use this if a token leaks or after removing temporary site access.', 'codex-wp-admin-bridge' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>

					<?php submit_button( __( 'Save bridge settings', 'codex-wp-admin-bridge' ) ); ?>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width: 980px; margin-top: 12px;">
					<?php wp_nonce_field( self::NONCE_ACTION ); ?>
					<input type="hidden" name="action" value="codex_wp_bridge_register_site">
					<?php submit_button( __( 'Sincronizar con MCP Hub ahora', 'codex-wp-admin-bridge' ), 'secondary', 'submit', false ); ?>
				</form>

				<h2><?php echo esc_html__( 'Authentication', 'codex-wp-admin-bridge' ); ?></h2>
				<p><?php echo esc_html__( 'Send the token as Authorization: Bearer <token> or X-Codex-Token: <token>.', 'codex-wp-admin-bridge' ); ?></p>
				<p><?php echo esc_html__( 'Optional advanced setup: define CODEX_WP_ADMIN_BRIDGE_TOKEN in wp-config.php to override the stored token with a universal credential of your own.', 'codex-wp-admin-bridge' ); ?></p>
				<h2><?php echo esc_html__( 'Recommended wp-config.php snippet', 'codex-wp-admin-bridge' ); ?></h2>
				<p><?php echo esc_html__( 'For your internal MSP workflow, use a fixed token and explicit site metadata.', 'codex-wp-admin-bridge' ); ?></p>
				<textarea readonly="readonly" class="large-text code" rows="5"><?php echo esc_textarea( $wp_config_snippet ); ?></textarea>

				<h2><?php echo esc_html__( 'Main endpoints', 'codex-wp-admin-bridge' ); ?></h2>
				<ul style="list-style: disc; padding-left: 20px;">
					<li><code>GET <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/site-info' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/rest-proxy' ) ); ?></code></li>
					<li><code>GET <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/plugins' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/plugins/action' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/plugins/install-zip' ) ); ?></code></li>
					<li><code>GET <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/themes' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/themes/activate' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/options/get' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/options/update' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/files/read' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/files/write' ) ); ?></code></li>
					<li><code>POST <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/db/query' ) ); ?></code></li>
				</ul>
			</div>
			<?php
		}

		public static function handle_settings_save() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to perform this action.', 'codex-wp-admin-bridge' ) );
			}

			check_admin_referer( self::NONCE_ACTION );

			$site_label      = isset( $_POST['site_label'] ) ? sanitize_text_field( wp_unslash( $_POST['site_label'] ) ) : '';
			$site_id         = isset( $_POST['site_id'] ) ? sanitize_key( wp_unslash( $_POST['site_id'] ) ) : '';
			$environment     = isset( $_POST['environment'] ) ? sanitize_key( wp_unslash( $_POST['environment'] ) ) : '';
			$service_user_id = isset( $_POST['service_user_id'] ) ? (int) $_POST['service_user_id'] : 0;
			$rotate_token    = ! empty( $_POST['rotate_token'] );

			if ( $site_label ) {
				update_option( self::OPTION_SITE_LABEL, $site_label, false );
			}

			if ( $site_id ) {
				update_option( self::OPTION_SITE_ID, $site_id, false );
			}

			if ( in_array( $environment, array( 'production', 'staging', 'development' ), true ) ) {
				update_option( self::OPTION_ENVIRONMENT, $environment, false );
			}

			update_option( self::OPTION_REGISTRY_URL, self::get_registry_url(), false );

			if ( $service_user_id > 0 && user_can( $service_user_id, 'manage_options' ) ) {
				update_option( self::OPTION_SERVICE_USER_ID, $service_user_id, false );
			}

			if ( $rotate_token ) {
				update_option( self::OPTION_TOKEN, self::generate_token(), false );
			}

			self::maybe_register_site();

			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => 'codex-wp-admin-bridge',
						'updated' => '1',
					),
					admin_url( 'tools.php' )
				)
			);
			exit;
		}

		public static function handle_register_site() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( esc_html__( 'You do not have permission to perform this action.', 'codex-wp-admin-bridge' ) );
			}

			check_admin_referer( self::NONCE_ACTION );
			self::register_site_with_registry();

			wp_safe_redirect(
				add_query_arg(
					array(
						'page'    => 'codex-wp-admin-bridge',
						'updated' => '1',
					),
					admin_url( 'tools.php' )
				)
			);
			exit;
		}

		public static function register_routes() {
			register_rest_route(
				self::REST_NAMESPACE,
				'/site-info',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'site_info' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/rest-proxy',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'rest_proxy' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/plugins',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'list_plugins' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/plugins/action',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'plugin_action' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/plugins/install-zip',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'install_plugin_zip' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/themes',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'list_themes' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/themes/activate',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'activate_theme' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/options/get',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'get_options' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/options/update',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'update_options' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/files/read',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'read_file' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/files/write',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'write_file' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/i18n/check',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'check_translations' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/i18n/check-plurals',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'check_plural_translations' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/wc/checkout-fields',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'get_checkout_fields' ),
				)
			);

			register_rest_route(
				self::REST_NAMESPACE,
				'/db/query',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( __CLASS__, 'permission_callback' ),
					'callback'            => array( __CLASS__, 'db_query' ),
				)
			);
		}

		public static function permission_callback( WP_REST_Request $request ) {
			$provided = self::get_request_token( $request );
			$expected = self::get_token();

			if ( ! $provided || ! $expected || ! hash_equals( $expected, $provided ) ) {
				return new WP_Error(
					'codex_bridge_unauthorized',
					__( 'Invalid or missing Codex bridge token.', 'codex-wp-admin-bridge' ),
					array( 'status' => 401 )
				);
			}

			$service_user_id = (int) get_option( self::OPTION_SERVICE_USER_ID );
			if ( $service_user_id <= 0 || ! user_can( $service_user_id, 'manage_options' ) ) {
				return new WP_Error(
					'codex_bridge_missing_admin',
					__( 'Bridge service user is not configured as an administrator.', 'codex-wp-admin-bridge' ),
					array( 'status' => 500 )
				);
			}

			wp_set_current_user( $service_user_id );

			return true;
		}

		public static function site_info() {
			return rest_ensure_response(
				array(
					'site_label'      => (string) get_option( self::OPTION_SITE_LABEL, get_bloginfo( 'name' ) ),
					'site_id'         => self::get_site_id(),
					'environment'     => self::get_environment(),
					'site_name'       => get_bloginfo( 'name' ),
					'site_url'        => home_url( '/' ),
					'bridge_url'      => rest_url( self::REST_NAMESPACE ),
					'bridge_version'  => '0.3.0',
					'wp_version'      => get_bloginfo( 'version' ),
					'php_version'     => PHP_VERSION,
					'is_multisite'    => is_multisite(),
					'active_plugins'  => self::get_active_plugins_summary(),
					'active_theme'    => wp_get_theme()->get_stylesheet(),
					'rest_namespace'  => self::REST_NAMESPACE,
					'service_user_id' => (int) get_option( self::OPTION_SERVICE_USER_ID ),
				)
			);
		}

		public static function rest_proxy( WP_REST_Request $request ) {
			$route  = '/' . ltrim( (string) $request->get_param( 'route' ), '/' );
			$method = strtoupper( (string) $request->get_param( 'method' ) );
			$params = $request->get_param( 'params' );
			$body   = $request->get_param( 'body' );

			if ( empty( $route ) || '/' === $route ) {
				return new WP_Error( 'codex_bridge_invalid_route', __( 'A target REST route is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			if ( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) ) {
				$method = 'GET';
			}

			$proxy_request = new WP_REST_Request( $method, $route );

			if ( is_array( $params ) ) {
				$proxy_request->set_query_params( $params );
				foreach ( $params as $key => $value ) {
					$proxy_request->set_param( $key, $value );
				}
			}

			if ( is_array( $body ) ) {
				$proxy_request->set_body( wp_json_encode( $body ) );
				$proxy_request->set_header( 'content-type', 'application/json' );
				if ( method_exists( $proxy_request, 'set_body_params' ) ) {
					$proxy_request->set_body_params( $body );
				}
				foreach ( $body as $key => $value ) {
					$proxy_request->set_param( $key, $value );
				}
			}

			$response = rest_do_request( $proxy_request );
			$server   = rest_get_server();

			return rest_ensure_response(
				array(
					'status' => $response->get_status(),
					'data'   => $server->response_to_data( $response, false ),
				)
			);
		}

		public static function list_plugins() {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$plugins = array();
			foreach ( get_plugins() as $plugin_file => $plugin_data ) {
				$plugins[] = array(
					'plugin_file' => $plugin_file,
					'name'        => isset( $plugin_data['Name'] ) ? $plugin_data['Name'] : '',
					'version'     => isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : '',
					'active'      => is_plugin_active( $plugin_file ),
				);
			}

			return rest_ensure_response( $plugins );
		}

		public static function plugin_action( WP_REST_Request $request ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$plugin_file = (string) $request->get_param( 'plugin_file' );
			$action      = (string) $request->get_param( 'action' );

			if ( ! $plugin_file ) {
				return new WP_Error( 'codex_bridge_missing_plugin', __( 'plugin_file is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			switch ( $action ) {
				case 'activate':
					$result = activate_plugin( $plugin_file, '', false, true );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
					break;
				case 'deactivate':
					deactivate_plugins( $plugin_file, true, false );
					break;
				case 'delete':
					require_once ABSPATH . 'wp-admin/includes/file.php';
					WP_Filesystem();
					$result = delete_plugins( array( $plugin_file ) );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
					break;
				default:
					return new WP_Error( 'codex_bridge_invalid_action', __( 'Unsupported plugin action.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			return rest_ensure_response(
				array(
					'plugin_file' => $plugin_file,
					'action'      => $action,
					'active'      => is_plugin_active( $plugin_file ),
				)
			);
		}

		public static function install_plugin_zip( WP_REST_Request $request ) {
			if ( ! class_exists( 'Plugin_Upgrader' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/misc.php';
				require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
				require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			$zip_base64 = (string) $request->get_param( 'zip_base64' );
			$filename   = sanitize_file_name( (string) $request->get_param( 'filename' ) );
			$activate   = (bool) $request->get_param( 'activate' );

			if ( ! $zip_base64 || ! $filename ) {
				return new WP_Error( 'codex_bridge_missing_zip', __( 'zip_base64 and filename are required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$temp_file = wp_tempnam( $filename );
			if ( ! $temp_file ) {
				return new WP_Error( 'codex_bridge_tempfile_failed', __( 'Unable to allocate a temporary file.', 'codex-wp-admin-bridge' ), array( 'status' => 500 ) );
			}

			$raw_zip = base64_decode( $zip_base64, true );
			if ( false === $raw_zip ) {
				@unlink( $temp_file );
				return new WP_Error( 'codex_bridge_bad_zip', __( 'zip_base64 is not valid base64.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			file_put_contents( $temp_file, $raw_zip );

			$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$result   = $upgrader->install( $temp_file );
			@unlink( $temp_file );

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! $result ) {
				return new WP_Error( 'codex_bridge_install_failed', __( 'Plugin installation failed.', 'codex-wp-admin-bridge' ), array( 'status' => 500 ) );
			}

			$plugin_file = $upgrader->plugin_info();

			if ( $activate && $plugin_file ) {
				$activation = activate_plugin( $plugin_file, '', false, true );
				if ( is_wp_error( $activation ) ) {
					return $activation;
				}
			}

			return rest_ensure_response(
				array(
					'installed'   => true,
					'plugin_file' => $plugin_file,
					'active'      => $plugin_file ? is_plugin_active( $plugin_file ) : false,
				)
			);
		}

		public static function list_themes() {
			$themes = array();
			foreach ( wp_get_themes() as $stylesheet => $theme ) {
				$themes[] = array(
					'stylesheet' => $stylesheet,
					'name'       => $theme->get( 'Name' ),
					'version'    => $theme->get( 'Version' ),
					'active'     => get_stylesheet() === $stylesheet,
				);
			}

			return rest_ensure_response( $themes );
		}

		public static function activate_theme( WP_REST_Request $request ) {
			$stylesheet = (string) $request->get_param( 'stylesheet' );
			if ( ! $stylesheet || ! wp_get_theme( $stylesheet )->exists() ) {
				return new WP_Error( 'codex_bridge_bad_theme', __( 'A valid theme stylesheet is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			switch_theme( $stylesheet );

			return rest_ensure_response(
				array(
					'active_theme' => get_stylesheet(),
				)
			);
		}

		public static function get_options( WP_REST_Request $request ) {
			$names = $request->get_param( 'options' );
			if ( ! is_array( $names ) || empty( $names ) ) {
				return new WP_Error( 'codex_bridge_missing_options', __( 'Provide an array of option names.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$data = array();
			foreach ( $names as $name ) {
				$name          = (string) $name;
				$data[ $name ] = get_option( $name );
			}

			return rest_ensure_response( $data );
		}

		public static function update_options( WP_REST_Request $request ) {
			$options = $request->get_param( 'options' );
			if ( ! is_array( $options ) || empty( $options ) ) {
				return new WP_Error( 'codex_bridge_missing_update_options', __( 'Provide an options object.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$updated = array();
			foreach ( $options as $name => $value ) {
				$name             = (string) $name;
				$updated[ $name ] = update_option( $name, $value, false );
			}

			return rest_ensure_response(
				array(
					'updated' => $updated,
				)
			);
		}

		public static function read_file( WP_REST_Request $request ) {
			$path = (string) $request->get_param( 'path' );
			if ( ! $path ) {
				return new WP_Error( 'codex_bridge_missing_path', __( 'path is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$resolved = self::resolve_path( $path, false );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			if ( ! is_file( $resolved ) || ! is_readable( $resolved ) ) {
				return new WP_Error( 'codex_bridge_unreadable_file', __( 'The target file is not readable.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			return rest_ensure_response(
				array(
					'path'    => self::relative_to_root( $resolved ),
					'content' => file_get_contents( $resolved ),
				)
			);
		}

		public static function write_file( WP_REST_Request $request ) {
			$path        = (string) $request->get_param( 'path' );
			$content     = (string) $request->get_param( 'content' );
			$encoding    = (string) $request->get_param( 'encoding' );
			$with_backup = (bool) $request->get_param( 'backup' );

			if ( ! $path ) {
				return new WP_Error( 'codex_bridge_missing_write_path', __( 'path is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$resolved = self::resolve_path( $path, true );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$directory = dirname( $resolved );
			if ( ! is_dir( $directory ) ) {
				wp_mkdir_p( $directory );
			}

			$backup_file = null;
			if ( $with_backup && file_exists( $resolved ) ) {
				$backup_file = $resolved . '.bak.' . gmdate( 'YmdHis' );
				copy( $resolved, $backup_file );
			}

			if ( 'base64' === strtolower( $encoding ) ) {
				$decoded = base64_decode( $content, true );

				if ( false === $decoded ) {
					return new WP_Error( 'codex_bridge_invalid_base64', __( 'content is not valid base64.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
				}

				$content = $decoded;
			}

			file_put_contents( $resolved, $content );

			return rest_ensure_response(
				array(
					'path'        => self::relative_to_root( $resolved ),
					'bytes'       => strlen( $content ),
					'backup_file' => $backup_file ? self::relative_to_root( $backup_file ) : null,
				)
			);
		}

		public static function db_query( WP_REST_Request $request ) {
			global $wpdb;

			$sql = trim( (string) $request->get_param( 'sql' ) );
			if ( ! $sql ) {
				return new WP_Error( 'codex_bridge_missing_sql', __( 'sql is required.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			if ( ! preg_match( '/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN)\s/i', $sql ) ) {
				return new WP_Error( 'codex_bridge_sql_not_allowed', __( 'Only read-only SQL statements are allowed.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$rows = $wpdb->get_results( $sql, ARRAY_A );
			if ( null === $rows && $wpdb->last_error ) {
				return new WP_Error( 'codex_bridge_sql_error', $wpdb->last_error, array( 'status' => 400 ) );
			}

			return rest_ensure_response(
				array(
					'rows'      => $rows,
					'row_count' => is_array( $rows ) ? count( $rows ) : 0,
				)
			);
		}

		public static function check_translations( WP_REST_Request $request ) {
			$strings = $request->get_param( 'strings' );
			$domain  = (string) $request->get_param( 'domain' );

			if ( ! is_array( $strings ) || empty( $strings ) ) {
				return new WP_Error( 'codex_bridge_missing_strings', __( 'Provide an array of strings.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			if ( ! $domain ) {
				$domain = 'default';
			}

			$results = array();

			foreach ( $strings as $string ) {
				$string             = (string) $string;
				$results[ $string ] = translate( $string, $domain );
			}

			return rest_ensure_response(
				array(
					'locale'  => function_exists( 'determine_locale' ) ? determine_locale() : get_locale(),
					'domain'  => $domain,
					'results' => $results,
				)
			);
		}

		public static function check_plural_translations( WP_REST_Request $request ) {
			$items  = $request->get_param( 'items' );
			$domain = (string) $request->get_param( 'domain' );

			if ( ! is_array( $items ) || empty( $items ) ) {
				return new WP_Error( 'codex_bridge_missing_plural_items', __( 'Provide an array of plural translation items.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			if ( ! $domain ) {
				$domain = 'default';
			}

			$results = array();

			foreach ( $items as $item ) {
				$singular = isset( $item['singular'] ) ? (string) $item['singular'] : '';
				$plural   = isset( $item['plural'] ) ? (string) $item['plural'] : '';
				$number   = isset( $item['number'] ) ? (int) $item['number'] : 2;

				if ( '' === $singular || '' === $plural ) {
					continue;
				}

				$key             = $singular . ' || ' . $plural . ' || ' . $number;
				$results[ $key ] = _n( $singular, $plural, $number, $domain );
			}

			return rest_ensure_response(
				array(
					'locale'  => function_exists( 'determine_locale' ) ? determine_locale() : get_locale(),
					'domain'  => $domain,
					'results' => $results,
				)
			);
		}

		public static function get_checkout_fields() {
			if ( ! function_exists( 'WC' ) ) {
				return new WP_Error( 'codex_bridge_woocommerce_missing', __( 'WooCommerce is not available.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$checkout = WC()->checkout();

			if ( ! $checkout ) {
				return new WP_Error( 'codex_bridge_checkout_unavailable', __( 'Checkout object is not available.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			$raw_fields = $checkout->get_checkout_fields();
			$fields     = array();

			foreach ( $raw_fields as $group => $group_fields ) {
				$fields[ $group ] = array();

				foreach ( $group_fields as $key => $field ) {
					$fields[ $group ][ $key ] = array(
						'label'       => isset( $field['label'] ) ? $field['label'] : '',
						'required'    => ! empty( $field['required'] ),
						'type'        => isset( $field['type'] ) ? $field['type'] : 'text',
						'priority'    => isset( $field['priority'] ) ? $field['priority'] : null,
						'placeholder' => isset( $field['placeholder'] ) ? $field['placeholder'] : '',
					);
				}
			}

			return rest_ensure_response( $fields );
		}

		private static function get_request_token( WP_REST_Request $request ) {
			$authorization = $request->get_header( 'authorization' );
			if ( $authorization && preg_match( '/Bearer\s+(.+)/i', $authorization, $matches ) ) {
				return trim( $matches[1] );
			}

			$header_token = $request->get_header( 'x-codex-token' );
			if ( $header_token ) {
				return trim( $header_token );
			}

			return '';
		}

		private static function get_token() {
			if ( defined( 'CODEX_WP_ADMIN_BRIDGE_TOKEN' ) && CODEX_WP_ADMIN_BRIDGE_TOKEN ) {
				return (string) CODEX_WP_ADMIN_BRIDGE_TOKEN;
			}

			return (string) get_option( self::OPTION_TOKEN, '' );
		}

		private static function get_site_id() {
			if ( defined( 'CODEX_WP_ADMIN_BRIDGE_SITE_ID' ) && CODEX_WP_ADMIN_BRIDGE_SITE_ID ) {
				return sanitize_key( (string) CODEX_WP_ADMIN_BRIDGE_SITE_ID );
			}

			$site_id = (string) get_option( self::OPTION_SITE_ID, '' );
			if ( $site_id ) {
				return sanitize_key( $site_id );
			}

			return self::build_default_site_id();
		}

		private static function get_environment() {
			if ( defined( 'CODEX_WP_ADMIN_BRIDGE_ENVIRONMENT' ) && CODEX_WP_ADMIN_BRIDGE_ENVIRONMENT ) {
				return sanitize_key( (string) CODEX_WP_ADMIN_BRIDGE_ENVIRONMENT );
			}

			$environment = (string) get_option( self::OPTION_ENVIRONMENT, 'production' );

			return in_array( $environment, array( 'production', 'staging', 'development' ), true ) ? $environment : 'production';
		}

		private static function get_registry_url() {
			if ( defined( 'CODEX_WP_BRIDGE_REGISTRY_URL' ) && CODEX_WP_BRIDGE_REGISTRY_URL ) {
				return esc_url_raw( (string) CODEX_WP_BRIDGE_REGISTRY_URL );
			}

			$saved = (string) get_option( self::OPTION_REGISTRY_URL, '' );
			if ( $saved ) {
				return esc_url_raw( $saved );
			}

			return esc_url_raw( self::INTERNAL_REGISTRY_URL );
		}

		private static function get_registry_token() {
			if ( defined( 'CODEX_WP_BRIDGE_REGISTRY_TOKEN' ) && CODEX_WP_BRIDGE_REGISTRY_TOKEN ) {
				return sanitize_text_field( (string) CODEX_WP_BRIDGE_REGISTRY_TOKEN );
			}

			return sanitize_text_field( (string) get_option( self::OPTION_REGISTRY_TOKEN, '' ) );
		}

		private static function get_default_admin_user_id() {
			$admins = get_users(
				array(
					'role__in' => array( 'administrator' ),
					'number'   => 1,
					'orderby'  => 'ID',
					'order'    => 'ASC',
					'fields'   => array( 'ID' ),
				)
			);

			return ! empty( $admins[0]->ID ) ? (int) $admins[0]->ID : 0;
		}

		private static function generate_token() {
			return wp_generate_password( 64, false, false );
		}

		private static function build_default_site_id() {
			$host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
			$host = $host ? preg_replace( '/[^a-z0-9]+/i', '-', strtolower( $host ) ) : 'wordpress-site';
			$host = trim( $host, '-' );

			if ( ! $host ) {
				$host = 'wordpress-site';
			}

			return sanitize_key( $host );
		}

		private static function maybe_register_site() {
			if ( ! self::get_registry_url() ) {
				update_option( self::OPTION_REGISTRY_STATUS, 'not_configured', false );
				update_option( self::OPTION_REGISTRY_ERROR, '', false );
				return false;
			}

			return self::register_site_with_registry();
		}

		private static function register_site_with_registry() {
			$registry_url   = self::get_registry_url();
			$registry_token = self::get_registry_token();

			if ( ! $registry_url ) {
				update_option( self::OPTION_REGISTRY_STATUS, 'not_configured', false );
				update_option( self::OPTION_REGISTRY_ERROR, 'Registry URL is missing.', false );
				return false;
			}

			$payload = array(
				'site_id'      => self::get_site_id(),
				'site_label'   => (string) get_option( self::OPTION_SITE_LABEL, get_bloginfo( 'name' ) ),
				'environment'  => self::get_environment(),
				'base_url'     => home_url( '/' ),
				'bridge_url'   => rest_url( self::REST_NAMESPACE ),
				'token'        => self::get_token(),
				'wp_version'   => get_bloginfo( 'version' ),
				'php_version'  => PHP_VERSION,
				'service_user' => (int) get_option( self::OPTION_SERVICE_USER_ID ),
			);

			$response = wp_remote_post(
				$registry_url,
				array(
					'timeout' => 15,
					'headers' => array_filter(
						array(
						'Content-Type'  => 'application/json',
						'X-Codex-Token' => self::get_token(),
						'Authorization' => $registry_token ? 'Bearer ' . $registry_token : '',
						)
					),
					'body'    => wp_json_encode( $payload ),
				)
			);

			if ( is_wp_error( $response ) ) {
				update_option( self::OPTION_REGISTRY_STATUS, 'error', false );
				update_option( self::OPTION_REGISTRY_ERROR, $response->get_error_message(), false );
				return false;
			}

			$status_code = (int) wp_remote_retrieve_response_code( $response );
			$body        = (string) wp_remote_retrieve_body( $response );

			if ( $status_code < 200 || $status_code >= 300 ) {
				update_option( self::OPTION_REGISTRY_STATUS, 'error', false );
				update_option( self::OPTION_REGISTRY_ERROR, $body ? wp_strip_all_tags( $body ) : 'Unexpected registry response.', false );
				return false;
			}

			update_option( self::OPTION_REGISTRY_STATUS, 'registered', false );
			update_option( self::OPTION_REGISTRY_ERROR, '', false );

			return true;
		}

		private static function get_active_plugins_summary() {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';

			$summary = array();
			foreach ( get_option( 'active_plugins', array() ) as $plugin_file ) {
				$data      = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file, false, false );
				$summary[] = array(
					'plugin_file' => $plugin_file,
					'name'        => isset( $data['Name'] ) ? $data['Name'] : $plugin_file,
					'version'     => isset( $data['Version'] ) ? $data['Version'] : '',
				);
			}

			return $summary;
		}

		private static function resolve_path( $path, $allow_missing_leaf ) {
			$root = wp_normalize_path( untrailingslashit( ABSPATH ) );
			$path = str_replace( array( "\0", '..\\', '../' ), '', (string) $path );

			if ( preg_match( '#^[A-Za-z]:[\\\\/]#', $path ) || '/' === substr( $path, 0, 1 ) ) {
				$candidate = wp_normalize_path( $path );
			} else {
				$candidate = wp_normalize_path( $root . '/' . ltrim( $path, '/\\' ) );
			}

			if ( file_exists( $candidate ) ) {
				$real = wp_normalize_path( realpath( $candidate ) );
			} elseif ( $allow_missing_leaf ) {
				$parent = dirname( $candidate );
				$real_parent = file_exists( $parent ) ? wp_normalize_path( realpath( $parent ) ) : wp_normalize_path( $parent );
				$real = $real_parent . '/' . basename( $candidate );
			} else {
				$real = $candidate;
			}

			if ( 0 !== strpos( $real, $root ) ) {
				return new WP_Error( 'codex_bridge_bad_path', __( 'The path is outside the WordPress root.', 'codex-wp-admin-bridge' ), array( 'status' => 400 ) );
			}

			return $real;
		}

		private static function relative_to_root( $path ) {
			$root = wp_normalize_path( untrailingslashit( ABSPATH ) );
			$path = wp_normalize_path( $path );

			if ( 0 === strpos( $path, $root ) ) {
				return ltrim( substr( $path, strlen( $root ) ), '/' );
			}

			return $path;
		}
	}

	Codex_WP_Admin_Bridge::init();
}
