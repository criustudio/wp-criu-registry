<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Conversation {
	private const TTL = 900;

	private static function welcome( $actor ) {
		$abilities = array();
		$available = static function ( $permission ) use ( $actor ) {
			return Triu_Commercial_Auth::can( false, $actor, $permission, 0 );
		};
		if ( $available( 'product.read' ) ) {
			$abilities[] = 'Buscar y consultar productos';
		}
		if ( $available( 'product.update.text' ) ) {
			$abilities[] = 'Actualizar nombres y descripciones de productos';
		}
		if ( $available( 'product.update.price' ) ) {
			$abilities[] = 'Cambiar precios de productos';
		}
		if ( $available( 'product.update.stock' ) ) {
			$abilities[] = 'Actualizar existencias';
		}
		if ( $available( 'product.update.media' ) ) {
			$abilities[] = 'Cambiar fotografías de productos';
		}
		if ( $available( 'product.trash' ) || $available( 'product.delete_permanently' ) ) {
			$abilities[] = 'Retirar productos, siempre después de confirmar';
		}
		if ( $available( 'page.update.content' ) ) {
			$abilities[] = 'Actualizar textos, enlaces e imágenes compatibles de tus páginas';
		}
		$site = sanitize_text_field( get_bloginfo( 'name' ) );
		if ( ! $abilities ) {
			return 'Ya estás vinculado con ' . $site . '. Tu acceso todavía no tiene cambios habilitados; consulta con el administrador del sitio.';
		}
		return '¡Listo! Ya estás vinculado con ' . $site . ".\nPuedo ayudarte con:\n• " . implode( "\n• ", $abilities ) . "\n\nCuéntame en tus palabras qué necesitas cambiar. Te pediré confirmación antes de aplicar un cambio.";
	}

	public static function receive( $message ) {
		$actor = (string) $message['from']['id'];
		$text = trim( (string) ( $message['text'] ?? $message['caption'] ?? '' ) );
		$photo = self::photo_id( $message );
		if ( preg_match( '/^\/start(?:@\w+)?(?:\s+([A-Za-z0-9]+))?$/', $text, $matches ) ) {
			if ( ! empty( $matches[1] ) && Triu_Commercial_Auth::pair( $actor, $message['from']['first_name'] ?? '', $matches[1] ) ) {
				return self::welcome( $actor );
			}
			return Triu_Commercial_Auth::is_linked( $actor ) ? self::welcome( $actor ) : 'Para usar este asistente, solicita tu enlace de invitación al administrador del sitio.';
		}
		if ( ! Triu_Commercial_Auth::is_linked( $actor ) ) {
			return 'Este chat aún no está autorizado. Solicita tu enlace de invitación al administrador del sitio.';
		}
		if ( preg_match( '/^\/cancelar(?:@\w+)?$/i', $text ) ) {
			self::clear( $actor );
			return 'Cancelé la solicitud. ¿Qué más necesitas?';
		}
		if ( preg_match( '/^\/ayuda(?:@\w+)?$/i', $text ) ) {
			return self::welcome( $actor ) . "\n\nSi quieres empezar rápido, escribe /producto NOMBRE. También puedes escribir /cancelar en cualquier momento.";
		}
		$state = self::state( $actor );
		if ( $state ) {
			return self::continue_flow( $actor, $state, $text, $photo );
		}
		if ( $photo ) {
			return 'Recibí la fotografía. Primero dime a qué producto o zona de la página quieres asignarla.';
		}
		if ( '' === $text ) {
			return 'Escríbeme qué producto o contenido quieres cambiar.';
		}
		if ( preg_match( '/^\/producto\s+(.+)$/iu', $text, $matches ) ) {
			return self::find_product( $actor, 'product_search', trim( $matches[1] ), '', '' );
		}
		if ( preg_match( '/^\/precio\s+(.+?)\s*\|\s*(.+)$/iu', $text, $matches ) ) {
			return self::find_product( $actor, 'product_update', trim( $matches[1] ), 'regular_price', trim( $matches[2] ) );
		}
		if ( preg_match( '/^\/imagen\s+(.+)$/iu', $text, $matches ) ) {
			return self::find_product( $actor, 'product_image', trim( $matches[1] ), '', '' );
		}
		if ( preg_match( '/^\/eliminar\s+(.+)$/iu', $text, $matches ) ) {
			return self::find_product( $actor, 'product_delete', trim( $matches[1] ), '', '' );
		}
		$intent = Triu_Commercial_Intent::parse( $text );
		if ( is_wp_error( $intent ) ) {
			return $intent->get_error_message() . ' También puedes buscar con /producto seguido del nombre.';
		}
		switch ( $intent['action'] ) {
			case 'product_search':
			case 'product_update':
			case 'product_image':
			case 'product_delete':
				return self::find_product( $actor, $intent['action'], $intent['product_query'], $intent['field'], $intent['value'] );
			case 'page_update':
			case 'page_image':
			case 'page_add_item':
				return self::find_slot( $actor, $intent['action'], $intent['slot_query'], $intent['value'] );
			case 'unsupported':
				return 'Ese cambio requiere trabajo de diseño o desarrollo. Contacta a tu desarrollador o a Criu Colombia para que te ayuden.';
			default:
				return 'No pude identificar el cambio. Dime el producto o la zona de la página y qué información quieres modificar.';
		}
	}

	private static function continue_flow( $actor, $state, $text, $photo ) {
		switch ( $state['phase'] ) {
			case 'await_product_query':
				return self::find_product( $actor, $state['action'], $text, $state['field'], $state['value'] );
			case 'select_product':
				$number = (int) $text;
				if ( ! preg_match( '/^[1-9][0-9]*$/', $text ) || ! isset( $state['choices'][ $number - 1 ] ) ) {
					return 'Responde con el número del producto que quieres usar, o escribe /cancelar.';
				}
				return self::target_product( $actor, $state['action'], $state['choices'][ $number - 1 ], $state['field'], $state['value'] );
			case 'await_value':
				if ( '' === $text ) {
					return 'Envíame el nuevo valor, o escribe /cancelar.';
				}
				return self::propose_product_value( $actor, $state['product_id'], $state['field'], $text );
			case 'confirm_update':
				$result = triu_commercial_products()->confirm_field_update( $actor, $state['proposal_id'], $text );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::clear( $actor );
				return 'Listo. Guardé el cambio en ' . $result['name'] . '.';
			case 'await_photo':
				if ( ! $photo ) {
					return 'Envíame la fotografía como imagen de Telegram, o escribe /cancelar.';
				}
				$proposal = triu_commercial_products()->propose_image_update( $actor, $state['product_id'], $photo );
				if ( is_wp_error( $proposal ) ) {
					return $proposal->get_error_message();
				}
				self::save( $actor, array( 'phase' => 'confirm_image', 'proposal_id' => $proposal['proposal_id'] ) );
				return 'Voy a usar esta fotografía como imagen principal de ' . $proposal['product_name'] . '. ¿Confirmas? Escribe CONFIRMO.';
			case 'confirm_image':
				$result = triu_commercial_products()->confirm_image_update( $actor, $state['proposal_id'], $text );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::clear( $actor );
				return 'Listo. Cambié la imagen principal de ' . $result['name'] . '.';
			case 'delete_mode':
				$lower = mb_strtolower( trim( $text ) );
				$mode = in_array( $lower, array( 'papelera', 'a la papelera' ), true ) ? 'trash' : ( in_array( $lower, array( 'definitivamente', 'eliminar definitivamente' ), true ) ? 'permanent' : '' );
				if ( ! $mode ) {
					return 'Elige “papelera” para poder restaurarlo después, o “definitivamente” para borrarlo por completo.';
				}
				$result = triu_commercial_products()->choose_deletion_mode( $actor, $state['request_id'], $mode );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::save( $actor, array( 'phase' => 'delete_confirm_first', 'request_id' => $state['request_id'], 'mode' => $mode, 'name' => $state['name'] ) );
				return 'Primera confirmación: ' . ( 'permanent' === $mode ? '¿quieres eliminar definitivamente ' : '¿quieres enviar a la papelera ' ) . $state['name'] . '? Escribe CONFIRMO.';
			case 'delete_confirm_first':
				$result = triu_commercial_products()->confirm_deletion( $actor, $state['request_id'], $text );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::save( $actor, array( 'phase' => 'delete_confirm_second', 'request_id' => $state['request_id'], 'mode' => $state['mode'], 'name' => $state['name'] ) );
				return 'Última confirmación para ' . $state['name'] . ': escribe exactamente ' . ( 'permanent' === $state['mode'] ? 'ELIMINAR DEFINITIVAMENTE. Se borrará por completo la información del producto.' : 'ENVIAR A PAPELERA. Podrás restaurarlo desde WordPress.' );
			case 'delete_confirm_second':
				$result = triu_commercial_products()->confirm_deletion( $actor, $state['request_id'], $text );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::clear( $actor );
				return 'permanent' === $state['mode'] ? 'Eliminé definitivamente ' . $state['name'] . '.' : 'Envié ' . $state['name'] . ' a la papelera.';
			case 'select_slot':
				$number = (int) $text;
				if ( ! preg_match( '/^[1-9][0-9]*$/', $text ) || ! isset( $state['choices'][ $number - 1 ] ) ) {
					return self::find_slot( $actor, $state['action'], $text, $state['value'] );
				}
				return self::target_slot( $actor, $state['action'], $state['choices'][ $number - 1 ], $state['value'] );
			case 'await_slot_query':
				return self::find_slot( $actor, $state['action'], $text, $state['value'] );
			case 'await_slot_value':
				if ( '' === $text ) {
					return 'Envíame el nuevo contenido, o escribe /cancelar.';
				}
				return self::propose_slot( $actor, $state['slot_id'], $text, '' );
			case 'await_slot_photo':
				if ( ! $photo ) {
					return 'Envíame una fotografía para esta zona, o escribe /cancelar.';
				}
				return self::propose_slot( $actor, $state['slot_id'], '', $photo );
			case 'confirm_slot':
				$result = Triu_Commercial_Elementor::confirm( $actor, $state['proposal_id'], $text );
				if ( is_wp_error( $result ) ) {
					return $result->get_error_message();
				}
				self::clear( $actor );
				return 'Listo. Actualicé ' . $result['slot'] . '. Puedes verlo en ' . $result['page_url'];
		}
		self::clear( $actor );
		return 'La solicitud anterior venció. Dime qué necesitas cambiar.';
	}

	private static function find_product( $actor, $action, $query, $field, $value ) {
		$query = trim( (string) $query );
		if ( '' === $query ) {
			self::save( $actor, array( 'phase' => 'await_product_query', 'action' => $action, 'field' => $field, 'value' => $value ) );
			return '¿Cuál producto quieres ' . ( 'product_delete' === $action ? 'retirar' : 'modificar o consultar' ) . '? Dime su nombre o SKU.';
		}
		$products = triu_commercial_products()->search_products( $actor, $query );
		if ( is_wp_error( $products ) ) {
			return $products->get_error_message();
		}
		if ( ! $products ) {
			return 'No encontré productos con ese nombre o SKU. Prueba con otra parte del nombre.';
		}
		if ( 1 === count( $products ) ) {
			return self::target_product( $actor, $action, $products[0]['id'], $field, $value );
		}
		$choices = array_column( $products, 'id' );
		self::save( $actor, array( 'phase' => 'select_product', 'action' => $action, 'field' => $field, 'value' => $value, 'choices' => $choices ) );
		$lines = array( 'Encontré estos productos. ¿Cuál quieres usar?' );
		foreach ( $products as $index => $product ) {
			$lines[] = ( $index + 1 ) . '. ' . $product['name'] . ( $product['sku'] ? ' (SKU ' . $product['sku'] . ')' : '' );
		}
		$lines[] = 'Responde con el número.';
		return implode( "\n", $lines );
	}

	private static function target_product( $actor, $action, $product_id, $field, $value ) {
		$product = triu_commercial_products()->get_product( $actor, $product_id );
		if ( is_wp_error( $product ) ) {
			return $product->get_error_message();
		}
		if ( 'product_search' === $action ) {
			self::clear( $actor );
			return $product['name'] . ( $product['sku'] ? ' · SKU ' . $product['sku'] : '' ) . ' · Precio normal: ' . self::display( $product['regular_price'] ) . ' · Precio de oferta: ' . self::display( $product['sale_price'] ) . ' · Inventario: ' . self::display( $product['stock_quantity'] ) . '.';
		}
		if ( 'product_delete' === $action ) {
			$request = triu_commercial_products()->begin_deletion( $actor, $product_id );
			if ( is_wp_error( $request ) ) {
				return $request->get_error_message();
			}
			self::save( $actor, array( 'phase' => 'delete_mode', 'request_id' => $request['request_id'], 'name' => $product['name'] ) );
			return 'Encontré ' . $product['name'] . '. ¿Quieres enviarlo a la papelera, desde donde se puede restaurar, o eliminarlo definitivamente? La eliminación definitiva borra por completo la información del producto y puede afectar enlaces que lo usen.';
		}
		if ( 'product_image' === $action ) {
			self::save( $actor, array( 'phase' => 'await_photo', 'product_id' => $product_id ) );
			return 'Voy a cambiar la imagen principal de ' . $product['name'] . '. Envíame la nueva fotografía.';
		}
		if ( ! in_array( $field, array( 'name', 'description', 'short_description', 'regular_price', 'sale_price', 'stock_quantity' ), true ) ) {
			self::clear( $actor );
			return 'Dime qué dato de ' . $product['name'] . ' quieres cambiar: nombre, descripción, precio o inventario.';
		}
		if ( '' === (string) $value ) {
			self::save( $actor, array( 'phase' => 'await_value', 'product_id' => $product_id, 'field' => $field ) );
			return '¿Cuál es el nuevo valor para ' . self::field_label( $field ) . ' de ' . $product['name'] . '?';
		}
		return self::propose_product_value( $actor, $product_id, $field, $value );
	}

	private static function propose_product_value( $actor, $product_id, $field, $value ) {
		$proposal = triu_commercial_products()->propose_field_update( $actor, $product_id, $field, $value );
		if ( is_wp_error( $proposal ) ) {
			return $proposal->get_error_message();
		}
		self::save( $actor, array( 'phase' => 'confirm_update', 'proposal_id' => $proposal['proposal_id'] ) );
		return 'Voy a cambiar ' . self::field_label( $field ) . ' de ' . $proposal['product_name'] . '. Antes: ' . self::display( $proposal['previous'] ) . '. Nuevo: ' . self::display( $proposal['value'] ) . '. ¿Confirmas? Escribe CONFIRMO.';
	}

	private static function find_slot( $actor, $action, $query, $value ) {
		if ( '' === trim( (string) $query ) ) {
			self::save( $actor, array( 'phase' => 'await_slot_query', 'action' => $action, 'value' => $value ) );
			return '¿En qué página aparece ese contenido? Si puedes, dime también el texto que ves cerca.';
		}
		$slots = Triu_Commercial_Elementor::matching_slots( $actor, $query );
		if ( is_wp_error( $slots ) ) {
			return $slots->get_error_message();
		}
		$kind = 'page_image' === $action ? 'image' : ( 'page_add_item' === $action ? 'repeater' : '' );
		$slots = array_filter( $slots, static function ( $slot ) use ( $kind ) {
			return $kind ? $kind === $slot['kind'] : in_array( $slot['kind'], array( 'text', 'url' ), true );
		} );
		if ( ! $slots ) {
			self::save( $actor, array( 'phase' => 'await_slot_query', 'action' => $action, 'value' => $value ) );
			return 'No encontré ese contenido entre las páginas publicadas o el elemento no admite este cambio. Dime el nombre de la página o el texto que aparece allí para buscarlo mejor.';
		}
		if ( count( $slots ) > 10 ) {
			self::save( $actor, array( 'phase' => 'await_slot_query', 'action' => $action, 'value' => $value ) );
			return 'Encontré varias opciones. ¿Qué texto aparece cerca del contenido o en qué sección de la página está?';
		}
		if ( 1 === count( $slots ) ) {
			return self::target_slot( $actor, $action, array_key_first( $slots ), $value );
		}
		$choices = array_keys( $slots );
		self::save( $actor, array( 'phase' => 'select_slot', 'action' => $action, 'value' => $value, 'choices' => $choices ) );
		$lines = array( 'Encontré estas opciones. ¿Cuál quieres cambiar?' );
		$index = 1;
		foreach ( $slots as $slot ) {
			$lines[] = $index++ . '. ' . $slot['label'] . ' (' . get_the_title( $slot['post_id'] ) . ')';
		}
		$lines[] = 'Responde con el número o descríbeme mejor cuál es.';
		return implode( "\n", $lines );
	}

	private static function target_slot( $actor, $action, $slot_id, $value ) {
		$slots = Triu_Commercial_Elementor::available_slots();
		if ( ! isset( $slots[ $slot_id ] ) ) {
			return 'No encontré ese contenido. Dime de nuevo qué quieres cambiar.';
		}
		$slot = $slots[ $slot_id ];
		if ( 'page_image' === $action ) {
			self::save( $actor, array( 'phase' => 'await_slot_photo', 'slot_id' => $slot_id ) );
			return 'Envíame la nueva fotografía para ' . $slot['label'] . '.';
		}
		if ( '' === trim( (string) $value ) ) {
			self::save( $actor, array( 'phase' => 'await_slot_value', 'slot_id' => $slot_id ) );
			return '¿Qué contenido quieres poner en ' . $slot['label'] . '?';
		}
		return self::propose_slot( $actor, $slot_id, $value, '' );
	}

	private static function propose_slot( $actor, $slot_id, $value, $file_id ) {
		$proposal = Triu_Commercial_Elementor::propose( $actor, $slot_id, $value, $file_id );
		if ( is_wp_error( $proposal ) ) {
			return $proposal->get_error_message();
		}
		self::save( $actor, array( 'phase' => 'confirm_slot', 'proposal_id' => $proposal['proposal_id'] ) );
		return 'Voy a actualizar ' . $proposal['slot']['label'] . ' en la página ' . get_the_title( $proposal['slot']['post_id'] ) . '. Valor anterior: ' . self::display( $proposal['previous'] ) . '. Nuevo: ' . ( $file_id ? 'la fotografía que enviaste' : self::display( $value ) ) . '. ¿Confirmas? Escribe CONFIRMO.';
	}

	private static function photo_id( $message ) {
		$photos = $message['photo'] ?? array();
		if ( ! is_array( $photos ) || ! $photos ) {
			return '';
		}
		$last = end( $photos );
		return is_array( $last ) ? (string) ( $last['file_id'] ?? '' ) : '';
	}

	private static function field_label( $field ) {
		$names = array( 'name' => 'el nombre', 'description' => 'la descripción', 'short_description' => 'la descripción corta', 'regular_price' => 'el precio normal', 'sale_price' => 'el precio de oferta', 'stock_quantity' => 'el inventario' );
		return $names[ $field ] ?? $field;
	}

	private static function display( $value ) {
		if ( is_array( $value ) ) {
			$value = $value['url'] ?? '[contenido compuesto]';
		}
		$value = trim( wp_strip_all_tags( (string) $value ) );
		return '' === $value ? '[vacío]' : mb_substr( $value, 0, 180 );
	}

	private static function state( $actor ) {
		$state = get_transient( 'triu_conversation_' . $actor );
		return is_array( $state ) ? $state : null;
	}

	private static function save( $actor, $state ) {
		set_transient( 'triu_conversation_' . $actor, $state, self::TTL );
	}

	private static function clear( $actor ) {
		delete_transient( 'triu_conversation_' . $actor );
	}
}
