<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Telegram {
	public static function register_route() {
		register_rest_route( 'triu-commercial/v1', '/status', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'callback' => static function () {
				return array(
					'version' => TRIU_COMMERCIAL_VERSION,
					'bot_managed_by_hub' => true,
					'ai_managed_by_hub' => true,
					'hub_site_id' => Triu_Commercial_Config::get( 'hub_site_id', '' ),
					'linked_users' => count( array_filter( Triu_Commercial_Auth::users(), static function ( $user ) { return ! empty( $user['active'] ); } ) ),
					'editable_slots' => count( Triu_Commercial_Elementor::slots() ),
				);
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/elementor-inventory/(?P<page_id>\d+)', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'callback' => static function ( $request ) {
				return Triu_Commercial_Elementor::inventory( (int) $request['page_id'] );
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/elementor-slot', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'callback' => static function ( $request ) {
				$id = Triu_Commercial_Elementor::add_slot( array(
					'label' => sanitize_text_field( (string) $request['label'] ),
					'post_id' => absint( $request['post_id'] ),
					'element_id' => sanitize_text_field( (string) $request['element_id'] ),
					'kind' => sanitize_key( (string) $request['kind'] ),
					'setting_key' => sanitize_key( (string) $request['setting_key'] ),
					'item_field' => sanitize_key( (string) $request['item_field'] ),
				) );
				return is_wp_error( $id ) ? $id : array( 'slot_id' => $id );
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/pair-code', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'callback' => static function ( $request ) {
				$permissions = (array) ( $request['permissions'] ?? array() );
				$code = Triu_Commercial_Auth::create_pair_code( $permissions );
				$url = self::invite_url( $code );
				return array( 'code' => $code, 'invite_url' => $url, 'expires_in_seconds' => 1200 );
			},
		) );
	}

	public static function verify_webhook( $request ) {
		$received = (string) $request->get_header( 'x-telegram-bot-api-secret-token' );
		$expected = Triu_Commercial_Config::webhook_secret();
		return '' !== $received && hash_equals( $expected, $received );
	}

	public static function webhook( $request ) {
		$update = $request->get_json_params();
		if ( ! is_array( $update ) || ! isset( $update['update_id'] ) ) {
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		$update_id = (int) $update['update_id'];
		$dedupe_key = 'triu_tg_update_' . $update_id;
		if ( get_transient( $dedupe_key ) ) {
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		$message = $update['message'] ?? null;
		if ( ! is_array( $message ) || 'private' !== ( $message['chat']['type'] ?? '' ) || ! isset( $message['from']['id'], $message['chat']['id'] ) ) {
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		set_transient( $dedupe_key, 1, DAY_IN_SECONDS );
		try {
			$reply = Triu_Commercial_Conversation::receive( $message );
			if ( '' !== $reply ) {
				$sent = self::api( 'sendMessage', array( 'chat_id' => $message['chat']['id'], 'text' => $reply ) );
				if ( is_wp_error( $sent ) ) {
					delete_transient( $dedupe_key );
					return new WP_Error( 'triu_telegram_send_failed', 'No se pudo entregar la respuesta.', array( 'status' => 503 ) );
				}
			}
		} catch ( Throwable $error ) {
			delete_transient( $dedupe_key );
			return new WP_Error( 'triu_telegram_processing_failed', 'No se pudo procesar el mensaje.', array( 'status' => 503 ) );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	public static function api( $method, $arguments = array() ) {
		$token = Triu_Commercial_Config::bot_token();
		if ( ! is_string( $token ) || '' === $token ) {
			return new WP_Error( 'triu_bot_unconfigured', 'El bot aún no está configurado.' );
		}
		$response = wp_remote_post( 'https://api.telegram.org/bot' . $token . '/' . $method, array(
			'timeout' => 20,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body' => wp_json_encode( $arguments ),
		) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'triu_telegram_unavailable', 'Telegram no respondió.' );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['ok'] ) ) {
			return new WP_Error( 'triu_telegram_error', 'Telegram no pudo completar la solicitud.' );
		}
		return $body['result'] ?? true;
	}

	public static function bot_username() {
		$username = (string) Triu_Commercial_Config::get( 'bot_username', '' );
		if ( preg_match( '/^[A-Za-z0-9_]{5,32}$/', $username ) ) {
			return $username;
		}
		$bot = self::api( 'getMe' );
		if ( is_wp_error( $bot ) || ! is_array( $bot ) || empty( $bot['username'] ) ) {
			return '';
		}
		$username = (string) $bot['username'];
		if ( ! preg_match( '/^[A-Za-z0-9_]{5,32}$/', $username ) ) {
			return '';
		}
		Triu_Commercial_Config::set( 'bot_username', $username );
		return $username;
	}

	public static function invite_url( $code ) {
		$username = self::bot_username();
		return '' === $username ? '' : 'https://t.me/' . $username . '?start=' . rawurlencode( (string) $code );
	}

	public static function set_webhook() {
		$current = self::api( 'getWebhookInfo' );
		if ( is_wp_error( $current ) ) {
			return $current;
		}
		$existing_url = is_array( $current ) ? (string) ( $current['url'] ?? '' ) : '';
		$site_url = rest_url( 'triu-commercial/v1/telegram' );
		if ( '' !== $existing_url && $existing_url !== $site_url ) {
			return new WP_Error( 'triu_bot_already_connected', 'Este bot ya está conectado a otra web. Usa el servicio central para compartirlo entre sitios.' );
		}
		return self::api( 'setWebhook', array(
			'url' => $site_url,
			'secret_token' => Triu_Commercial_Config::webhook_secret(),
			'allowed_updates' => array( 'message' ),
			'max_connections' => 1,
			'drop_pending_updates' => false,
		) );
	}
}
