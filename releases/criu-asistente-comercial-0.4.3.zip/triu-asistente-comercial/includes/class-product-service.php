<?php
/**
 * Controlled WooCommerce operations. No public route is exposed at this stage.
 */

defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Product_Service {
	private const DELETE_TTL = 900;
	private const DELETE_PREFIX = 'triu_delete_';
	private const UPDATE_PREFIX = 'triu_update_';
	private const IMAGE_PREFIX = 'triu_image_';

	public function search_products( $actor_id, $term ) {
		$allowed = $this->authorize( $actor_id, 'product.read', 0 );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}
		$term = trim( sanitize_text_field( (string) $term ) );
		if ( '' === $term ) {
			return array();
		}
		$found = array();
		$sku_matches = wc_get_products( array( 'sku' => $term, 'limit' => 10, 'status' => array( 'publish', 'draft', 'private' ) ) );
		foreach ( $sku_matches as $product ) {
			$found[ $product->get_id() ] = $this->snapshot( $product );
		}
		$exact = wc_get_products( array( 'name' => $term, 'limit' => 10, 'status' => array( 'publish', 'draft', 'private' ) ) );
		foreach ( $exact as $product ) {
			$found[ $product->get_id() ] = $this->snapshot( $product );
		}
		for ( $page = 1; $page <= 5 && count( $found ) < 10; $page++ ) {
			$batch = wc_get_products( array( 'limit' => 100, 'page' => $page, 'status' => array( 'publish', 'draft', 'private' ), 'orderby' => 'title', 'order' => 'ASC' ) );
			foreach ( $batch as $product ) {
				if ( false !== mb_stripos( $product->get_name(), $term ) || false !== mb_stripos( $product->get_sku(), $term ) ) {
					$found[ $product->get_id() ] = $this->snapshot( $product );
				}
				if ( count( $found ) >= 10 ) {
					break;
				}
			}
			if ( count( $batch ) < 100 ) {
				break;
			}
		}
		return array_values( $found );
	}

	/**
	 * Get a product's commercial fields.
	 *
	 * @param string $actor_id Stable, site-scoped actor ID.
	 * @param int    $product_id WooCommerce product ID.
	 * @return array|WP_Error
	 */
	public function get_product( $actor_id, $product_id ) {
		$allowed = $this->authorize( $actor_id, 'product.read', $product_id );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$product = $this->load_product( $product_id );
		if ( is_wp_error( $product ) ) {
			return $product;
		}

		return $this->snapshot( $product );
	}

	/**
	 * Prepare one field update without writing it.
	 *
	 * @param string $actor_id Actor ID.
	 * @param int    $product_id Product ID.
	 * @param string $field Allowed field name.
	 * @param mixed  $value New value.
	 * @return array|WP_Error
	 */
	public function propose_field_update( $actor_id, $product_id, $field, $value ) {
		$permissions = $this->field_permissions();
		if ( ! isset( $permissions[ $field ] ) ) {
			return new WP_Error( 'triu_unsupported_field', 'Este campo no se puede cambiar desde el asistente.' );
		}
		$allowed = $this->authorize( $actor_id, $permissions[ $field ], $product_id );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}
		$product = $this->load_product( $product_id );
		if ( is_wp_error( $product ) ) {
			return $product;
		}
		if ( in_array( $field, array( 'regular_price', 'sale_price', 'stock_quantity' ), true ) && ! $product->is_type( array( 'simple', 'variation' ) ) ) {
			return new WP_Error( 'triu_unsupported_product_type', 'Este cambio necesita revisar una variación específica del producto.' );
		}
		if ( 'stock_quantity' === $field && ! $product->get_manage_stock() ) {
			return new WP_Error( 'triu_stock_not_managed', 'Este producto no lleva inventario controlado. Contacta al administrador para habilitarlo.' );
		}
		$normalized = $this->normalize_field_value( $field, $value );
		if ( is_wp_error( $normalized ) ) {
			return $normalized;
		}
		$getter = 'get_' . $field;
		$previous = $product->$getter();
		$proposal_id = wp_generate_uuid4();
		set_transient(
			self::UPDATE_PREFIX . $proposal_id,
			array(
				'actor_id' => (string) $actor_id,
				'product_id' => (int) $product_id,
				'field' => $field,
				'previous' => $previous,
				'value' => $normalized,
				'version' => $this->version( $product ),
			),
			self::DELETE_TTL
		);
		return array(
			'proposal_id' => $proposal_id,
			'product_id' => (int) $product_id,
			'product_name' => $product->get_name(),
			'field' => $field,
			'previous' => $previous,
			'value' => $normalized,
			'expires_in_seconds' => self::DELETE_TTL,
		);
	}

	/**
	 * Apply only the exact proposal confirmed by its original actor.
	 *
	 * @param string $actor_id Actor ID.
	 * @param string $proposal_id Opaque proposal ID.
	 * @param string $answer Must be CONFIRMO.
	 * @return array|WP_Error
	 */
	public function confirm_field_update( $actor_id, $proposal_id, $answer ) {
		if ( 'CONFIRMO' !== trim( (string) $answer ) ) {
			return new WP_Error( 'triu_confirmation_required', 'Escribe CONFIRMO para aplicar el cambio.' );
		}
		if ( ! is_string( $proposal_id ) || ! preg_match( '/^[a-f0-9-]{36}$/i', $proposal_id ) ) {
			return new WP_Error( 'triu_invalid_proposal', 'La propuesta no es válida.' );
		}
		$state = get_transient( self::UPDATE_PREFIX . $proposal_id );
		if ( ! is_array( $state ) || ! hash_equals( $state['actor_id'], (string) $actor_id ) ) {
			return new WP_Error( 'triu_proposal_expired', 'La propuesta venció o no pertenece a esta persona.' );
		}
		$permissions = $this->field_permissions();
		$field = $state['field'];
		$product_id = $state['product_id'];
		$allowed = $this->authorize( $actor_id, $permissions[ $field ], $product_id );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$product = $this->load_product( $product_id );
		if ( is_wp_error( $product ) ) {
			return $product;
		}

		if ( ! $this->same_version( $product, $state['version'] ) ) {
			delete_transient( self::UPDATE_PREFIX . $proposal_id );
			return new WP_Error( 'triu_stale_product', 'El producto cambió mientras lo confirmabas. Revisa los datos actuales.' );
		}
		$value = $state['value'];
		switch ( $field ) {
			case 'name':
				$product->set_name( $value );
				break;
			case 'description':
				$product->set_description( $value );
				break;
			case 'short_description':
				$product->set_short_description( $value );
				break;
			case 'regular_price':
			case 'sale_price':
				if ( 'regular_price' === $field ) {
					$product->set_regular_price( $value );
				} else {
					$product->set_sale_price( $value );
				}
				break;
			case 'stock_quantity':
				$product->set_stock_quantity( (int) $value );
				break;
		}

		try {
			$saved = $product->save();
		} catch ( Throwable $error ) {
			return new WP_Error( 'triu_update_failed', 'No se pudo guardar el cambio.' );
		}
		if ( ! $saved ) {
			return new WP_Error( 'triu_update_failed', 'No se pudo guardar el cambio.' );
		}

		delete_transient( self::UPDATE_PREFIX . $proposal_id );
		Triu_Commercial_Audit::record( $actor_id, 'product.update.' . $field, $product_id, 'ok', array( 'previous' => $state['previous'], 'value' => $value ) );
		return $this->snapshot( wc_get_product( $product_id ) );
	}

	public function propose_image_update( $actor_id, $product_id, $telegram_file_id ) {
		$allowed = $this->authorize( $actor_id, 'product.update.media', $product_id );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}
		$product = $this->load_product( $product_id );
		if ( is_wp_error( $product ) ) {
			return $product;
		}
		if ( ! is_string( $telegram_file_id ) || strlen( $telegram_file_id ) > 256 || '' === $telegram_file_id ) {
			return new WP_Error( 'triu_invalid_photo', 'La fotografía no es válida.' );
		}
		$proposal_id = wp_generate_uuid4();
		set_transient( self::IMAGE_PREFIX . $proposal_id, array(
			'actor_id' => (string) $actor_id,
			'product_id' => (int) $product_id,
			'file_id' => $telegram_file_id,
			'version' => $this->version( $product ),
			'previous_image_id' => $product->get_image_id(),
		), self::DELETE_TTL );
		return array( 'proposal_id' => $proposal_id, 'product_name' => $product->get_name(), 'previous_image_id' => $product->get_image_id() );
	}

	public function confirm_image_update( $actor_id, $proposal_id, $answer ) {
		if ( 'CONFIRMO' !== trim( (string) $answer ) || ! is_string( $proposal_id ) || ! preg_match( '/^[a-f0-9-]{36}$/i', $proposal_id ) ) {
			return new WP_Error( 'triu_confirmation_required', 'Escribe CONFIRMO para cambiar la imagen.' );
		}
		$state = get_transient( self::IMAGE_PREFIX . $proposal_id );
		if ( ! is_array( $state ) || ! hash_equals( $state['actor_id'], (string) $actor_id ) ) {
			return new WP_Error( 'triu_proposal_expired', 'La propuesta venció o no pertenece a esta persona.' );
		}
		$allowed = $this->authorize( $actor_id, 'product.update.media', $state['product_id'] );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}
		$product = $this->load_product( $state['product_id'] );
		if ( is_wp_error( $product ) || ! $this->same_version( $product, $state['version'] ) ) {
			delete_transient( self::IMAGE_PREFIX . $proposal_id );
			return new WP_Error( 'triu_stale_product', 'El producto cambió. Revisa los datos actuales antes de cambiar su imagen.' );
		}
		$attachment_id = Triu_Commercial_Media::from_telegram( $state['file_id'], $product->get_id() );
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}
		try {
			$product->set_image_id( $attachment_id );
			$saved = $product->save();
		} catch ( Throwable $error ) {
			wp_delete_attachment( $attachment_id, true );
			return new WP_Error( 'triu_image_update_failed', 'No se pudo asignar la imagen al producto.' );
		}
		if ( ! $saved ) {
			wp_delete_attachment( $attachment_id, true );
			return new WP_Error( 'triu_image_update_failed', 'No se pudo asignar la imagen al producto.' );
		}
		delete_transient( self::IMAGE_PREFIX . $proposal_id );
		Triu_Commercial_Audit::record( $actor_id, 'product.update.image', $product->get_id(), 'ok', array( 'previous_image_id' => $state['previous_image_id'], 'image_id' => $attachment_id ) );
		return $this->snapshot( wc_get_product( $product->get_id() ) );
	}

	private function field_permissions() {
		return array(
			'name' => 'product.update.text',
			'description' => 'product.update.text',
			'short_description' => 'product.update.text',
			'regular_price' => 'product.update.price',
			'sale_price' => 'product.update.price',
			'stock_quantity' => 'product.update.stock',
		);
	}

	private function normalize_field_value( $field, $value ) {
		switch ( $field ) {
			case 'name':
				return sanitize_text_field( (string) $value );
			case 'description':
			case 'short_description':
				return wp_kses_post( (string) $value );
			case 'regular_price':
			case 'sale_price':
				return $this->normalize_price( $value );
			case 'stock_quantity':
				if ( filter_var( $value, FILTER_VALIDATE_INT ) === false || (int) $value < 0 ) {
					return new WP_Error( 'triu_invalid_stock', 'El inventario debe ser un número entero mayor o igual a cero.' );
				}
				return (int) $value;
		}
		return new WP_Error( 'triu_unsupported_field', 'Este campo no se puede cambiar desde el asistente.' );
	}

	private function normalize_price( $value ) {
		$value = trim( preg_replace( '/\s+/u', '', (string) $value ) );
		if ( '' === $value ) {
			return '';
		}
		if ( preg_match( '/^\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?$/', $value ) ) {
			$value = str_replace( '.', '', $value );
			$value = str_replace( ',', '.', $value );
		} elseif ( preg_match( '/^\d+(?:[.,]\d{1,2})?$/', $value ) ) {
			$value = str_replace( ',', '.', $value );
		} else {
			return new WP_Error( 'triu_invalid_price', 'No entendí el precio. Escríbelo como 49900 o 49.900.' );
		}
		if ( (float) $value < 0 ) {
			return new WP_Error( 'triu_invalid_price', 'El precio debe ser mayor o igual a cero.' );
		}
		return wc_format_decimal( $value );
	}

	/**
	 * Begin deletion without changing the product.
	 *
	 * @return array|WP_Error Request ID, product snapshot and available modes.
	 */
	public function begin_deletion( $actor_id, $product_id ) {
		$allowed = $this->authorize( $actor_id, 'product.trash', $product_id );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$product = $this->load_product( $product_id );
		if ( is_wp_error( $product ) ) {
			return $product;
		}

		$request_id = wp_generate_uuid4();
		$state      = array(
			'actor_id' => (string) $actor_id,
			'product_id' => (int) $product_id,
			'version' => $this->version( $product ),
			'phase' => 'choose',
			'mode' => null,
		);
		set_transient( self::DELETE_PREFIX . $request_id, $state, self::DELETE_TTL );

		return array(
			'request_id' => $request_id,
			'product' => $this->snapshot( $product ),
			'modes' => array( 'trash', 'permanent' ),
			'expires_in_seconds' => self::DELETE_TTL,
		);
	}

	/**
	 * Choose trash or permanent deletion. Both require two later confirmations.
	 *
	 * @return array|WP_Error
	 */
	public function choose_deletion_mode( $actor_id, $request_id, $mode ) {
		$state = $this->deletion_state( $actor_id, $request_id, 'choose' );
		if ( is_wp_error( $state ) ) {
			return $state;
		}
		if ( ! in_array( $mode, array( 'trash', 'permanent' ), true ) ) {
			return new WP_Error( 'triu_invalid_delete_mode', 'Elige papelera o eliminación definitiva.' );
		}

		$capability = 'permanent' === $mode ? 'product.delete_permanently' : 'product.trash';
		$allowed    = $this->authorize( $actor_id, $capability, $state['product_id'] );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$state['mode']  = $mode;
		$state['phase'] = 'confirm_first';
		set_transient( self::DELETE_PREFIX . $request_id, $state, self::DELETE_TTL );
		return array( 'phase' => 'confirm_first', 'mode' => $mode, 'product_id' => $state['product_id'] );
	}

	/**
	 * Confirm deletion twice. The second phrase is explicit for each mode.
	 *
	 * @return array|WP_Error
	 */
	public function confirm_deletion( $actor_id, $request_id, $answer ) {
		$state = $this->deletion_state( $actor_id, $request_id, null );
		if ( is_wp_error( $state ) ) {
			return $state;
		}
		if ( ! in_array( $state['phase'], array( 'confirm_first', 'confirm_second' ), true ) ) {
			return new WP_Error( 'triu_wrong_phase', 'Primero elige papelera o eliminación definitiva.' );
		}

		$capability = 'permanent' === $state['mode'] ? 'product.delete_permanently' : 'product.trash';
		$allowed    = $this->authorize( $actor_id, $capability, $state['product_id'] );
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$product = $this->load_product( $state['product_id'] );
		if ( is_wp_error( $product ) || ! $this->same_version( $product, $state['version'] ) ) {
			delete_transient( self::DELETE_PREFIX . $request_id );
			return new WP_Error( 'triu_stale_product', 'El producto cambió. Inicia una nueva solicitud para retirarlo.' );
		}

		if ( 'confirm_first' === $state['phase'] ) {
			if ( 'CONFIRMO' !== trim( (string) $answer ) ) {
				return new WP_Error( 'triu_confirmation_required', 'Escribe CONFIRMO para continuar.' );
			}
			$state['phase'] = 'confirm_second';
			set_transient( self::DELETE_PREFIX . $request_id, $state, self::DELETE_TTL );
			return array( 'phase' => 'confirm_second', 'mode' => $state['mode'], 'product_id' => $state['product_id'] );
		}

		$required = 'permanent' === $state['mode'] ? 'ELIMINAR DEFINITIVAMENTE' : 'ENVIAR A PAPELERA';
		if ( $required !== trim( (string) $answer ) ) {
			return new WP_Error( 'triu_final_confirmation_required', 'Escribe la frase de confirmación indicada para continuar.' );
		}

		try {
			$deleted = $product->delete( 'permanent' === $state['mode'] );
		} catch ( Throwable $error ) {
			return new WP_Error( 'triu_delete_failed', 'No se pudo retirar el producto.' );
		}
		if ( ! $deleted ) {
			return new WP_Error( 'triu_delete_failed', 'No se pudo retirar el producto.' );
		}
		delete_transient( self::DELETE_PREFIX . $request_id );
		Triu_Commercial_Audit::record( $actor_id, 'product.delete.' . $state['mode'], $state['product_id'], 'ok', array( 'mode' => $state['mode'] ) );
		return array( 'phase' => 'done', 'mode' => $state['mode'], 'product_id' => $state['product_id'] );
	}

	private function authorize( $actor_id, $permission, $product_id ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new WP_Error( 'triu_woocommerce_missing', 'WooCommerce no está disponible.' );
		}
		if ( ! is_string( $actor_id ) || '' === $actor_id ) {
			return new WP_Error( 'triu_actor_missing', 'No se identificó a la persona que solicitó el cambio.' );
		}
		$allowed = (bool) apply_filters( 'triu_commercial_user_can', false, $actor_id, $permission, (int) $product_id );
		if ( ! $allowed ) {
			return new WP_Error( 'triu_forbidden', 'No tienes permiso para realizar esta acción.' );
		}
		return true;
	}

	private function load_product( $product_id ) {
		$product = wc_get_product( (int) $product_id );
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return new WP_Error( 'triu_product_missing', 'No encontré ese producto.' );
		}
		return $product;
	}

	private function version( $product ) {
		return hash( 'sha256', wp_json_encode( $product->get_data() ) );
	}

	private function same_version( $product, $expected ) {
		return is_string( $expected ) && hash_equals( $this->version( $product ), $expected );
	}

	private function snapshot( $product ) {
		return array(
			'id' => $product->get_id(),
			'name' => $product->get_name(),
			'sku' => $product->get_sku(),
			'status' => $product->get_status(),
			'regular_price' => $product->get_regular_price(),
			'sale_price' => $product->get_sale_price(),
			'stock_quantity' => $product->get_stock_quantity(),
			'image_id' => $product->get_image_id(),
			'modified' => $this->version( $product ),
		);
	}

	private function deletion_state( $actor_id, $request_id, $expected_phase ) {
		if ( ! is_string( $request_id ) || ! preg_match( '/^[a-f0-9-]{36}$/i', $request_id ) ) {
			return new WP_Error( 'triu_invalid_request', 'La solicitud de eliminación no es válida.' );
		}
		$state = get_transient( self::DELETE_PREFIX . $request_id );
		if ( ! is_array( $state ) || ! hash_equals( $state['actor_id'], (string) $actor_id ) ) {
			return new WP_Error( 'triu_delete_expired', 'La solicitud venció o no pertenece a esta persona.' );
		}
		if ( null !== $expected_phase && $state['phase'] !== $expected_phase ) {
			return new WP_Error( 'triu_wrong_phase', 'Esta confirmación ya no corresponde a la solicitud actual.' );
		}
		return $state;
	}
}
