=== Codex WP Admin Bridge ===
Contributors: openai-codex-local
Tags: api, admin, woocommerce, elementor, jetbooking
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Administrative bridge for Codex to manage WordPress, WooCommerce, Elementor, JetEngine, and JetBooking with a dedicated token.

== Description ==

Codex WP Admin Bridge is a temporary or permanent control layer for WordPress sites that need to be operated from Codex without setting up WordPress application passwords on every project.

Main capabilities in v0.3:

* Dedicated bridge token
* Stable site ID and environment metadata for MSP registry use
* Optional auto-registration to wp_criu through a registry URL and token
* Service-user execution as an administrator
* Generic proxy to internal WordPress REST routes
* Plugin listing, activation, deactivation, deletion, and ZIP install
* Theme listing and activation
* Bulk option read/update
* File read/write inside the WordPress root
* Read-only database queries for plugin-specific tables and metadata

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install the ZIP from the WordPress admin.
2. Activate `Codex WP Admin Bridge`.
3. Go to `Tools > Codex Bridge`.
4. Set `Site label`, `Site ID`, and `Environment` under `Tools > Codex Bridge`.
5. Copy the token and REST base URL.
6. Optionally define the bridge constants in `wp-config.php` if you want one MSP token and explicit site metadata:

```
define( 'CODEX_WP_ADMIN_BRIDGE_TOKEN', 'YOUR_PRIVATE_MSP_TOKEN' );
define( 'CODEX_WP_ADMIN_BRIDGE_SITE_ID', 'my-site-prod' );
define( 'CODEX_WP_ADMIN_BRIDGE_ENVIRONMENT', 'production' );
```

== Authentication ==

Send either of these headers:

* `Authorization: Bearer YOUR_TOKEN`
* `X-Codex-Token: YOUR_TOKEN`

== Endpoints ==

Namespace: `codex-bridge/v1`

* `GET /site-info`
* `POST /rest-proxy`
* `GET /plugins`
* `POST /plugins/action`
* `POST /plugins/install-zip`
* `GET /themes`
* `POST /themes/activate`
* `POST /options/get`
* `POST /options/update`
* `POST /files/read`
* `POST /files/write`
* `POST /db/query`

== Security notes ==

This plugin grants high-privilege administrative access to the site. Treat the token like a root credential.

Recommended practice:

* install only while needed, or rotate the token after temporary work;
* assign the bridge to a dedicated administrator account;
* do not expose the token in public logs or screenshots;
* keep DB queries read-only unless a future controlled write endpoint is added intentionally.
