<?php
defined( 'ABSPATH' ) || exit;

final class Triu_Commercial_Hub {
	public static function maybe_register() {
		if ( ! current_user_can( 'manage_options' ) || Triu_Commercial_Config::get( 'hub_site_id' ) || get_transient( 'triu_commercial_registration_retry' ) ) {
			return;
		}
		set_transient( 'triu_commercial_registration_retry', 1, 10 * MINUTE_IN_SECONDS );
		self::connect();
	}

	public static function register_routes() {
		register_rest_route( 'triu-commercial/v1', '/hub-connect', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'callback' => static function ( $request ) {
				$result = self::connect();
				return is_wp_error( $result ) ? $result : array( 'connected' => true, 'site_id' => Triu_Commercial_Config::get( 'hub_site_id' ) );
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/hub-challenge', array(
			'methods' => WP_REST_Server::READABLE,
			'permission_callback' => '__return_true',
			'callback' => static function ( $request ) {
				$nonce = (string) $request->get_param( 'nonce' );
				$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
				if ( ! $secret || ! preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $nonce ) ) {
					return new WP_Error( 'criu_challenge_invalid', 'Solicitud no válida.', array( 'status' => 400 ) );
				}
				return array( 'proof' => hash_hmac( 'sha256', $nonce, $secret ) );
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/hub-link', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => array( __CLASS__, 'verify_request' ),
			'callback' => static function ( $request ) {
				$id = (string) $request->get_param( 'telegram_id' );
				if ( ! preg_match( '/^[0-9]{1,20}$/', $id ) ) {
					return new WP_Error( 'criu_actor_invalid', 'Usuario no válido.', array( 'status' => 400 ) );
				}
				Triu_Commercial_Auth::link_from_hub( $id, (string) $request->get_param( 'first_name' ), (array) $request->get_param( 'permissions' ) );
				return array( 'linked' => true );
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/hub-message', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => array( __CLASS__, 'verify_request' ),
			'callback' => static function ( $request ) {
				if ( (string) $request->get_param( 'site_id' ) !== (string) Triu_Commercial_Config::get( 'hub_site_id' ) ) {
					return new WP_Error( 'criu_site_invalid', 'Conexión no válida.', array( 'status' => 403 ) );
				}
				$message = $request->get_param( 'message' );
				if ( ! is_array( $message ) || ! isset( $message['from']['id'] ) || ! Triu_Commercial_Auth::is_linked( (string) $message['from']['id'] ) ) {
					return new WP_Error( 'criu_actor_invalid', 'Usuario no autorizado.', array( 'status' => 403 ) );
				}
				$key = 'criu_hub_reply_' . hash( 'sha256', (string) $request->get_header( 'x-criu-request-id' ) );
				$cached = get_transient( $key );
				if ( is_array( $cached ) ) {
					return $cached;
				}
				$result = array( 'reply' => Triu_Commercial_Conversation::receive( $message ) );
				set_transient( $key, $result, DAY_IN_SECONDS );
				return $result;
			},
		) );
		register_rest_route( 'triu-commercial/v1', '/hub-revoke', array(
			'methods' => WP_REST_Server::CREATABLE,
			'permission_callback' => array( __CLASS__, 'verify_request' ),
			'callback' => static function ( $request ) {
				$id = (string) $request->get_param( 'telegram_id' );
				if ( ! preg_match( '/^[0-9]{1,20}$/', $id ) ) {
					return new WP_Error( 'criu_actor_invalid', 'Usuario no válido.', array( 'status' => 400 ) );
				}
				Triu_Commercial_Auth::revoke_from_hub( $id );
				return array( 'revoked' => true );
			},
		) );
	}

	public static function verify_request( $request ) {
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		$timestamp = (string) $request->get_header( 'x-criu-timestamp' );
		$request_id = (string) $request->get_header( 'x-criu-request-id' );
		$received = (string) $request->get_header( 'x-criu-signature' );
		if ( ! $secret || ! ctype_digit( $timestamp ) || abs( time() - (int) $timestamp ) > 300 || ! preg_match( '/^[A-Za-z0-9_-]{6,80}$/', $request_id ) || ! preg_match( '/^[a-f0-9]{64}$/i', $received ) ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', $timestamp . '.' . $request_id . '.' . $request->get_body(), $secret );
		return hash_equals( $expected, strtolower( $received ) );
	}

	public static function connect() {
		$hub_url = 'https://mcp.criu.com.co';
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		if ( ! $secret ) {
			$secret = bin2hex( random_bytes( 32 ) );
			Triu_Commercial_Config::set( 'hub_site_secret', $secret );
		}
		$response = wp_remote_post( $hub_url . '/commercial/v1/sites/register', array(
			'timeout' => 20,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body' => wp_json_encode( array(
				'site_url' => home_url( '/' ),
				'site_label' => get_bloginfo( 'name' ),
				'site_secret' => $secret,
			) ),
		) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'criu_hub_connect_failed', 'El panel Criu no pudo registrar esta web. Comprueba que el sitio sea público y tenga HTTPS.' );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['siteId'] ) ) {
			return new WP_Error( 'criu_hub_invalid_reply', 'El panel Criu no confirmó el registro.' );
		}
		Triu_Commercial_Config::set( 'hub_url', $hub_url );
		Triu_Commercial_Config::set( 'hub_site_id', sanitize_text_field( (string) $body['siteId'] ) );
		Triu_Commercial_Config::set( 'hub_connected_at', current_time( 'mysql', true ) );
		if ( ! Triu_Commercial_Config::get( 'service_user_id' ) && get_current_user_id() ) {
			Triu_Commercial_Config::set( 'service_user_id', get_current_user_id() );
		}
		return true;
	}

	public static function parse_intent( $message ) {
		$url = (string) Triu_Commercial_Config::get( 'hub_url' );
		$site_id = (string) Triu_Commercial_Config::get( 'hub_site_id' );
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		if ( ! $url || ! $site_id || ! $secret ) {
			return new WP_Error( 'criu_hub_not_connected', 'La conexión con Criu aún no está lista.' );
		}
		$body = wp_json_encode( array( 'message' => mb_substr( (string) $message, 0, 2000 ) ) );
		$timestamp = (string) time();
		$response = wp_remote_post( $url . '/commercial/v1/intent', array(
			'timeout' => 25,
			'headers' => array(
				'Content-Type' => 'application/json',
				'X-Criu-Site-ID' => $site_id,
				'X-Criu-Timestamp' => $timestamp,
				'X-Criu-Signature' => hash_hmac( 'sha256', $timestamp . '.' . mb_substr( (string) $message, 0, 2000 ), $secret ),
			),
			'body' => $body,
		) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'criu_ai_unavailable', 'No pude interpretar la solicitud ahora. Intenta de nuevo.' );
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) && is_array( $data['intent'] ?? null ) ? $data['intent'] : new WP_Error( 'criu_ai_invalid', 'No entendí la solicitud. Intenta decirlo de otra forma.' );
	}

	public static function media_url( $file_id ) {
		$url = (string) Triu_Commercial_Config::get( 'hub_url' );
		$site_id = (string) Triu_Commercial_Config::get( 'hub_site_id' );
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		if ( ! $url || ! $site_id || ! $secret || ! preg_match( '/^[A-Za-z0-9_-]{10,256}$/', $file_id ) ) {
			return '';
		}
		$timestamp = (string) time();
		$signature = hash_hmac( 'sha256', $site_id . '.' . $file_id . '.' . $timestamp, $secret );
		return add_query_arg( array( 'site_id' => $site_id, 'timestamp' => $timestamp, 'signature' => $signature ), $url . '/commercial/v1/media/' . rawurlencode( $file_id ) );
	}

	public static function revoke_remote( $telegram_id ) {
		$url = (string) Triu_Commercial_Config::get( 'hub_url' );
		$site_id = (string) Triu_Commercial_Config::get( 'hub_site_id' );
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		if ( ! $url || ! $site_id || ! $secret ) {
			return true;
		}
		$body = wp_json_encode( array( 'telegram_id' => (string) $telegram_id ) );
		$timestamp = (string) time();
		$response = wp_remote_post( $url . '/commercial/v1/sites/' . rawurlencode( $site_id ) . '/revoke', array(
			'timeout' => 15,
			'headers' => array( 'Content-Type' => 'application/json', 'X-Criu-Timestamp' => $timestamp, 'X-Criu-Signature' => hash_hmac( 'sha256', $timestamp . '.' . (string) $telegram_id, $secret ) ),
			'body' => $body,
		) );
		return ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response );
	}

	public static function create_invitation( $permissions ) {
		$url = (string) Triu_Commercial_Config::get( 'hub_url' );
		$site_id = (string) Triu_Commercial_Config::get( 'hub_site_id' );
		$secret = (string) Triu_Commercial_Config::get( 'hub_site_secret' );
		if ( ! $url || ! $site_id || ! $secret ) {
			return new WP_Error( 'criu_hub_not_connected', 'La conexión con Criu aún no está lista.' );
		}
		$allowed = array_keys( Triu_Commercial_Auth::permissions() );
		$granted = array_values( array_intersect( $allowed, array_filter( (array) $permissions, 'is_string' ) ) );
		if ( ! $granted ) {
			return new WP_Error( 'criu_permissions_empty', 'Selecciona al menos un permiso.' );
		}
		$body = wp_json_encode( array( 'permissions' => $granted ) );
		$timestamp = (string) time();
		$response = wp_remote_post( $url . '/commercial/v1/sites/' . rawurlencode( $site_id ) . '/invitations', array(
			'timeout' => 15,
			'headers' => array( 'Content-Type' => 'application/json', 'X-Criu-Timestamp' => $timestamp, 'X-Criu-Signature' => hash_hmac( 'sha256', $timestamp . '.' . implode( ',', $granted ), $secret ) ),
			'body' => $body,
		) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'criu_invitation_failed', 'No pude crear el enlace de invitación. Intenta de nuevo.' );
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $data ) && ! empty( $data['url'] ) ? esc_url_raw( (string) $data['url'] ) : new WP_Error( 'criu_invitation_invalid', 'El panel Criu no devolvió un enlace válido.' );
	}
}
